# Want to create a common practices document from the GitHub GBioinfoCPD repo. 
# TODO: Long term. Update to output a version, not a date. 
# Ask Yuan best practice, maybe a yaml file? Should we try to use GitFlow eventually?
create_common_practices_docx = function(output_dir){
  date = format(Sys.Date(), "%Y%m%d")
  output_file = sprintf("%s/%s_CommonPractices.docx", output_dir, date)
  rmarkdown::render("create_document.Rmd", word_document(), output_file = output_file)
  print(sprintf("Successfully created Word Document of Common Practices at %s", output_file))
}

# Example: 
# create_common_practices_docx("docx_creation")