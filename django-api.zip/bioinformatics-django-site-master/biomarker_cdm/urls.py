from django.urls import path, include

urlpatterns = [
    path('v1/', include(('biomarker_cdm.api_v1.urls', 'api_v1'), namespace='biomarker_api_v1')),
]