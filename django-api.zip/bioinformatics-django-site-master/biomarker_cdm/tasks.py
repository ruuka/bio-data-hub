# Create your tasks here
from celery import shared_task
from time import time, sleep
from icecream import ic
import pandas as pd
import requests
import functools
import asyncio
import aiometer
from io import BytesIO
import httpx
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import xmltodict
from django.core.mail import EmailMessage
import os
from biomarker_cdm.models import StandardName, Synonym
from collections import OrderedDict

NCBI_API_KEY = 'd93ed756a97a480203cf78262e1761295207'
NCBI_RATE_LIMIT_PER_SECOND = 45
DEFAULT_TIMEOUT = 2  # seconds


def send_mail_w_attachment(to, subject, message, attachment,
                           mimetype='application/vnd.ms-excel', fail_silently=False):
    """
    :param to: a list of email addresses
    :param subject: a string
    :param message: a string
    :param attachment_path: full path to attachment fil
    """
    if to[0].lower().endswith('@gilead.com'):
        email = EmailMessage(subject, message, to=to)
        email.attach('Database Update.xlsx', attachment, mimetype=mimetype)

        # Send it
        email.send(fail_silently=fail_silently)



class TimeoutHTTPAdapter(HTTPAdapter):
    def __init__(self, *args, **kwargs):
        self.timeout = DEFAULT_TIMEOUT
        if "timeout" in kwargs:
            self.timeout = kwargs["timeout"]
            del kwargs["timeout"]
        super().__init__(*args, **kwargs)

    def send(self, request, **kwargs):
        timeout = kwargs.get("timeout")
        if timeout is None:
            kwargs["timeout"] = self.timeout
        return super().send(request, **kwargs)


http = requests.Session()
# Mount it for both http and https usage
retries = Retry(total=3, backoff_factor=0.5, status_forcelist=[429, 500, 502, 503, 504])
adapter = TimeoutHTTPAdapter(timeout=2, max_retries=retries)
http.mount("https://", adapter)
http.mount("http://", adapter)


@shared_task
def get_alternative_names_from_uniprot(uniprot_code):
    def process_name(name_field):
        if isinstance(name_field, str):
            return name_field
        elif isinstance(name_field, OrderedDict):
            if '#text' in name_field:
                return name_field['#text']
        elif isinstance(name_field, list):
            for list_entry in list:
                if isinstance(list_entry, str):
                    return list_entry
        raise ValueError('Unknown Field Value')

    def process_dict_entry(dict_entry):
        if 'shortName' in dict_entry:
            return [dict_entry['fullName'], dict_entry['shortName']]
        else:
            return [dict_entry['fullName'], ]

    r = http.get('https://www.uniprot.org/uniprot/{0}.xml'.format(str(uniprot_code)))
    sleep(0.05)
    if r.status_code == 200:
        parsed_response = xmltodict.parse(r.text)
        recommended_name = process_name(parsed_response['uniprot']['entry']['protein']['recommendedName']['fullName'])
        other_designations = []
        other_designations.extend(process_dict_entry(parsed_response['uniprot']['entry']['protein']['recommendedName']))
        if 'alternativeName' in parsed_response['uniprot']['entry']['protein']:
            if isinstance(parsed_response['uniprot']['entry']['protein']['alternativeName'], list):
                for alt_name in parsed_response['uniprot']['entry']['protein']['alternativeName']:
                    other_designations.extend(process_dict_entry(alt_name))
            else:
                other_designations.extend(
                    process_dict_entry(parsed_response['uniprot']['entry']['protein']['alternativeName']))
        return {
            'preferred_name': recommended_name,
            'other_designations': other_designations,
            'source_value': uniprot_code,
        }
    else:
        return {'preferred_name': '', 'other_designations': [], 'source_value': uniprot_code}


@shared_task
def process_protein_codes_from_uniprot(list_of_uniprot_codes):
    list_of_processed_data = []
    for uniprot_code in list_of_uniprot_codes:
        list_of_processed_data.append(get_alternative_names_from_uniprot(uniprot_code))
    log_processed_data(list_of_processed_data, 'Uniprot Alternative Names', [])


@shared_task
def get_gene_id_from_ncbi(query):
    sleep(1 / NCBI_RATE_LIMIT_PER_SECOND)
    r = http.get(
        'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=gene&term={0}%20AND%20human&sort=relevance&retmax=1&api_key={1}'.format(
            query, NCBI_API_KEY))
    if r.status_code == 200:
        parsed_response = xmltodict.parse(r.text)
        if parsed_response['eSearchResult']['IdList'] == None:
            sleep(1 / NCBI_RATE_LIMIT_PER_SECOND)
            r = http.get(
                'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/espell.fcgi?term={0}&db=gene&api_key={1}'.format(query,
                                                                                                                NCBI_API_KEY))
            spelling_parsed_response = xmltodict.parse(r.text)
            corrected_term = spelling_parsed_response['eSpellResult']['CorrectedQuery']
            sleep(1 / NCBI_RATE_LIMIT_PER_SECOND)
            r = http.get(
                'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=gene&term={0}%20AND%20human&sort=relevance&retmax=1&api_key={1}'.format(
                    corrected_term, NCBI_API_KEY))
            parsed_response = xmltodict.parse(r.text)
        if parsed_response['eSearchResult']['IdList'] != None:
            return parsed_response['eSearchResult']['IdList']['Id']
        else:
            return None
    else:
        return None


@shared_task
def get_alternative_names_from_ncbi(gene_id):
    if gene_id is None:
        return {'preferred_name': '', 'other_designations': [], 'source_value': None}
    else:
        sleep(1 / NCBI_RATE_LIMIT_PER_SECOND)
        r = http.get(
            'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=gene&id={0}&rettype=docsum&retmode=xml&api_key={1}'.format(
                gene_id, NCBI_API_KEY))
        if r.status_code == 200:
            parsed_response = xmltodict.parse(r.text)
            # If Gene ID Moved
            if parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['OtherDesignations'] is None:
                if 'CurrentID' in parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']:
                    if parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['CurrentID'] == str(0):
                        return {'preferred_name': '', 'other_designations': [], 'source_value': None}
                    else:
                        current_id = parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['CurrentID']
                        sleep(1 / NCBI_RATE_LIMIT_PER_SECOND)
                        r = http.get(
                            'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=gene&id={0}&rettype=docsum&retmode=xml&api_key={1}'.format(
                                current_id, NCBI_API_KEY))
                        parsed_response = xmltodict.parse(r.text)
                else:
                    return {'preferred_name': '', 'other_designations': [], 'source_value': None}
            other_designations = parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary'][
                'OtherDesignations'].split('|')
            return {'preferred_name': other_designations[0], 'other_designations': other_designations[1:],
                    'source_value': other_designations[0]}
        else:
            return {'preferred_name': '', 'other_designations': [], 'source_value': None}


@shared_task
def log_processed_data(list_of_processed_data, source: str, list_of_biomarker_names=[]):
    for index, indiv_response in enumerate(list_of_processed_data):
        if indiv_response['preferred_name'] == '' or indiv_response['preferred_name'] is None:
            continue
        std_name_instance, created = StandardName.objects.get_or_create(
            standard_name=indiv_response['preferred_name'],
            defaults={
                'source': source,
                'source_value': indiv_response['source_value']
            }
        )
        for indiv_response_synonym in indiv_response['other_designations'] + [indiv_response['preferred_name']]:
            synonym_instance, created = Synonym.objects.update_or_create(
                synonym=indiv_response_synonym,
                defaults={
                    'standard_name': std_name_instance,
                    'source': source,
                }
            )
        if len(list_of_biomarker_names) > 0:
            synonym_instance, created = Synonym.objects.update_or_create(
                synonym=list_of_biomarker_names[index],
                defaults={
                    'standard_name': std_name_instance,
                    'source': source,
                }
            )


@shared_task
def process_list_of_biomarker_names_from_ncbi(list_of_biomarker_names):
    # Search for Gene IDs
    parsed_search_data = []
    biomarkers_already_in_database = Synonym.objects. \
        filter(synonym__in=list_of_biomarker_names). \
        values_list('synonym', flat=True)
    filtered_list_of_biomarkers = [x for x in list_of_biomarker_names if x not in biomarkers_already_in_database]
    loop_start_time = time()
    ic(list_of_biomarker_names)
    for biomarker_name in filtered_list_of_biomarkers:
        ic(filtered_list_of_biomarkers)
        sleep(max(0, 1 / NCBI_RATE_LIMIT_PER_SECOND - time() - loop_start_time))
        parsed_search_data.append(get_gene_id_from_ncbi(biomarker_name))
        loop_start_time = time()

    sleep(0.25)
    # Fetch Gene Information
    parsed_fetch_data = []
    loop_start_time = time()
    for gene_id in parsed_search_data:
        sleep(max(0, 1 / NCBI_RATE_LIMIT_PER_SECOND - time() - loop_start_time))
        parsed_fetch_data.append(get_alternative_names_from_ncbi(gene_id))
        loop_start_time = time()

    log_processed_data(parsed_fetch_data, 'NCBI Other Designations', filtered_list_of_biomarkers)

    # send_mail(
    #     'Subject',
    #     'Message Sent',
    #     'john.austin@gilead.com',
    #     ['john.austin@gilead.com'],
    #     fail_silently=False,
    # )


@shared_task
def process_test_code_library(lut_dict):
    # Clear all previous records
    Synonym.objects.all().delete()
    StandardName.objects.all().delete()
    for synonym, standard in lut_dict.items():
        standard_object, created = StandardName.objects.get_or_create(
            standard_name=standard,
        )
        synonym_object = Synonym.objects.get_or_create(
            synonym=synonym,
            standard_name_id=standard_object.pk,
        )
        synonym_object = Synonym.objects.get_or_create(
            synonym=standard,
            standard_name_id=standard_object.pk
        )


async def call_url(session, url_obj):
    response = await session.request(method='GET', url=url_obj['url'])
    return {'response': response, 'query': url_obj['query'], 'original_query': url_obj['original_query']}


async def call_multiple_urls(urls):
    async with httpx.AsyncClient() as client:
        jobs = [functools.partial(call_url, client, u) for u in urls]
        r = await aiometer.run_all(jobs, max_at_once=30, max_per_second=NCBI_RATE_LIMIT_PER_SECOND)
        # r = await asyncio.gather(*[call_url(client, u) for u in urls])
    return r


def parse_gene_ids(response_list):
    gene_id_lookups = []
    # Extract Gene IDs for All Queries
    for r in response_list:
        if r['response'].status_code == 200:
            parsed_response = xmltodict.parse(r['response'].text)
            if parsed_response['eSearchResult']['IdList'] == None:
                lookup_obj = {
                    'spelling_correct_required': True,
                    'status_200': True,
                    'gene_id': None,
                    'query': r['query'],
                    'original_query': r['original_query'],
                    'preferred_name': None,
                }
            else:
                lookup_obj = {
                    'spelling_correct_required': False,
                    'status_200': True,
                    'gene_id': parsed_response['eSearchResult']['IdList']['Id'],
                    'query': r['query'],
                    'original_query': r['original_query'],
                    'preferred_name': None,
                }
        else:
            lookup_obj = {
                'spelling_correct_required': False,
                'status_200': False,
                'gene_id': None,
                'query': r['query'],
                'original_query': r['original_query'],
                'preferred_name': None,
            }
        gene_id_lookups.append(lookup_obj.copy())
    return gene_id_lookups


def parse_spelling_corrections(response_list):
    spelling_correct_lookups = []
    for r in response_list:
        if r['response'].status_code == 200:
            parsed_response = xmltodict.parse(r['response'].text)
            corrected_term = parsed_response['eSpellResult']['CorrectedQuery']
            lookup_obj = {
                'spelling_correct_required': True,
                'status_200': True,
                'gene_id': None,
                'query': corrected_term,
                'original_query': r['query'],
                'preferred_name': None,
            }
        else:
            lookup_obj = {
                'spelling_correct_required': True,
                'status_200': False,
                'gene_id': None,
                'query': r['query'],
                'original_query': r['query'],
                'preferred_name': None,
            }
        spelling_correct_lookups.append(lookup_obj.copy())
    return spelling_correct_lookups


def parse_standard_names(response_list: [str], lookup_type: str):
    gene_id_lookups = []
    for r in response_list:
        if r['response'].status_code == 200:
            parsed_response = xmltodict.parse(r['response'].text)
            # If Gene ID Moved
            if parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['OtherDesignations'] is None:
                if 'CurrentID' in parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']:
                    if parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['CurrentID'] == str(0):
                        lookup_obj = {
                            'spelling_correct_required': False,
                            'status_200': False,
                            'gene_id': None,
                            'query': r['query'],
                            'original_query': r['original_query'],
                            'preferred_name': None,
                        }
                    else:
                        new_gene_id = parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['CurrentID']
                        sleep(1 / NCBI_RATE_LIMIT_PER_SECOND)
                        r = http.get('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=gene&id={0}&rettype=docsum&retmode=xml&api_key={1}'.format(new_gene_id, NCBI_API_KEY))
                        parsed_response = xmltodict.parse(r.text)
                else:
                    lookup_obj = {
                        'spelling_correct_required': False,
                        'status_200': False,
                        'gene_id': None,
                        'query': r['query'],
                        'original_query': r['original_query'],
                        'preferred_name': None,
                    }
            other_designations = parsed_response['eSummaryResult']['DocumentSummarySet']['DocumentSummary']['OtherDesignations'].split('|')
            lookup_obj = {
                'spelling_correct_required': False,
                'status_200': False,
                'gene_id': None,
                'query': r['query'],
                'original_query': r['original_query'],
                'preferred_name': other_designations[0],
            }
        else:
            lookup_obj = {
                'spelling_correct_required': False,
                'status_200': True,
                'gene_id': None,
                'query': r['query'],
                'original_query': r['original_query'],
                'preferred_name': None,
            }
        gene_id_lookups.append(lookup_obj.copy())
    return gene_id_lookups


def process_async(urls):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    response_list = loop.run_until_complete(call_multiple_urls(urls))
    loop.close()
    return response_list


@shared_task
def email_standard_names(synonym_list, data_type, email_address):
    database_list = list(Synonym.objects.
                                    filter(synonym__in=synonym_list).
                                    select_related('standard_name').
                                    values('synonym', 'standard_name__standard_name')
                         )
    if len(database_list) > 0:
        database_df = pd.DataFrame(database_list)
        database_df['Source'] = 'Gilead Test Code Library'
        database_df['Corrected Lookup Name'] = 'NA'
        database_df.rename(columns={'synonym': 'Lookup Name', 'standard_name__standard_name': 'Standard Name'}, inplace=True)
    else:
        database_df = pd.DataFrame(columns=['Lookup Name', 'Standard Name', 'Source'])
    synonyms_not_in_database = [x for x in synonym_list if x not in database_df['Lookup Name'].unique()]
    if len(synonyms_not_in_database) > 0:  # Do if at least some of the synonyms aren't in the database
        # Perform Initial Search by Terms
        search_urls = [{
            'url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=gene&term={0}%20AND%20human&sort=relevance&retmax=1&api_key={1}'.format(x, NCBI_API_KEY),
            'query': x,
            'original_query': x,
        } for x in synonyms_not_in_database]
        response_list = process_async(search_urls)
        gene_id_lookups = parse_gene_ids(response_list)

        # Find Spelling Corrections for Any Terms Missing Gene IDs
        spelling_correct_urls = [{
            'url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/espell.fcgi?term={0}&db=gene&api_key={1}'.format(x['query'], NCBI_API_KEY),
            'query': x['query'],
            'original_query': x['query'],
        } for x in gene_id_lookups if x['spelling_correct_required'] is True]
        if len(spelling_correct_urls) > 0:
            spelling_correct_response_list = process_async(spelling_correct_urls)
            spelling_correct_lookups = parse_spelling_corrections(spelling_correct_response_list)

            # Find Gene IDs for Spelling Corrected Terms
            corrected_search_urls = [{
                'url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=gene&term={0}%20AND%20human&sort=relevance&retmax=1&api_key={1}'.format(x['query'], NCBI_API_KEY),
                'query': x['query'],
                'original_query': x['original_query'],
            } for x in spelling_correct_lookups if x['query'] != x['original_query']]
            corrected_spelling_response_list = process_async(corrected_search_urls)
            corrected_gene_id_lookups = parse_gene_ids(corrected_spelling_response_list)
        else:
            corrected_gene_id_lookups = []

        # Merge Gene IDs
        valid_gene_id_urls = [{
            'url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=gene&id={0}&rettype=docsum&retmode=xml&api_key={1}'.format(x['gene_id'], NCBI_API_KEY),
            'query': x['query'],
            'original_query': x['original_query'],
        } for x in gene_id_lookups if x['gene_id'] is not None]
        valid_gene_id_urls.extend([{
            'url': 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=gene&id={0}&rettype=docsum&retmode=xml&api_key={1}'.format(x['gene_id'], NCBI_API_KEY),
            'query': x['query'],
            'original_query': x['original_query'],
        } for x in corrected_gene_id_lookups if x['gene_id'] is not None])

        # Search Gene IDs for Preferred Gene or Protein Names
        gene_data_response_list = process_async(valid_gene_id_urls)
        gene_id_result_lookups = parse_standard_names(gene_data_response_list, lookup_type=data_type)

        # Convert to DataFrame and Populate Desired Columns
        completed_lookups = [x for x in gene_id_result_lookups if x['preferred_name'] is not None]
        ncbi_df = pd.DataFrame(completed_lookups).\
            drop(columns=['spelling_correct_required', 'status_200', 'gene_id']).\
            rename(columns={
            'query': 'Corrected Lookup Name',
            'original_query': 'Lookup Name',
            'preferred_name': 'Standard Name',
            })
        ncbi_df['Source'] = 'NCBI'
        ncbi_df['Corrected Lookup Name'] = ncbi_df.apply(lambda x: 'NA' if x['Corrected Lookup Name'] == x['Lookup Name'] else x['Corrected Lookup Name'], axis=1)
        complete_df = pd.concat([database_df, ncbi_df], ignore_index=True)
        with BytesIO() as b:
            complete_df.to_excel(b, index=False)
            b.seek(0)
            send_mail_w_attachment((email_address,), 'Standard Name Request',
                                   'Attached you will find your standard name request, completed.', b.read())

