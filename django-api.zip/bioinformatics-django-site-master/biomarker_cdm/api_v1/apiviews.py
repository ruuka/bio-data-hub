from django.utils.decorators import method_decorator
from django.views.generic import View
from rest_framework.generics import ListAPIView, RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
from icecream import ic
from django.core.mail import EmailMessage
from django.http import HttpResponse, JsonResponse
from django.db.models import Subquery
from io import BytesIO
from ..models import Synonym, StandardName
import pandas as pd
import json
from django.views.decorators.csrf import csrf_exempt

from .serializers.serializers import StandardNameSerializer, SynonymNameSerializer, BasicSynonymSerializer
from ..tasks import process_list_of_biomarker_names_from_ncbi, get_gene_id_from_ncbi, get_alternative_names_from_ncbi,\
    process_protein_codes_from_uniprot, get_alternative_names_from_uniprot, process_test_code_library, \
    email_standard_names


def send_mail_w_attachment(to, subject, message, attachment,
                           mimetype='application/vnd.ms-excel', fail_silently=False):
    """
    :param to: a list of email addresses
    :param subject: a string
    :param message: a string
    :param attachment_path: full path to attachment fil
    """
    if to[0].lower().endswith('@gilead.com'):
        email = EmailMessage(subject, message, to=to)
        email.attach('Database Update.xlsx', attachment, mimetype=mimetype)

        # Send it
        email.send(fail_silently=fail_silently)


class UploadBiomarkersForStandardization(View):
    def get(self, request, *args, **kwargs):
        list_of_biomarkers = request.GET.get('biomarkers', '').split('|')
        email_address = request.GET.get('email', '')
        list_of_biomarkers = [x for x in list_of_biomarkers if len(x) > 2]
        process_list_of_biomarker_names_from_ncbi(list_of_biomarkers)
        if (isinstance(email_address, str) and email_address.lower().endswith('@gilead.com')):
            df = pd.DataFrame.from_records(Synonym.objects.filter(standard_name_id__in=Subquery(Synonym.objects.filter(synonym__in=list_of_biomarkers).values('standard_name_id'))).select_related('standard_name').values_list('synonym', 'standard_name__standard_name', 'standard_name__source', 'standard_name__source_value'), columns=['Related Name', 'Standard Name', 'Standard Name Source', 'Standard Name Source Value'])
            with BytesIO() as b:
                df.to_excel(b, index=False)
                b.seek(0)
                send_mail_w_attachment((email_address,), 'Biomarker Database Update', 'Attached you will find your recent updates to the Biomarker database.', b.read())
        return HttpResponse('Entries Updated Successfully in Database')


class UploadUniprotCodesForStandardization(View):
    def get(self, request, *args, **kwargs):
        list_of_uniprot_codes = request.GET.get('uniprot', '').split('|')
        email_address = request.GET.get('email', '')
        process_protein_codes_from_uniprot(list_of_uniprot_codes)
        if (isinstance(email_address, str) and email_address.lower().endswith('@gilead.com')):
            df = pd.DataFrame.from_records(Synonym.objects.filter(standard_name_id__in=Subquery(StandardName.objects.filter(source_value__in=list_of_uniprot_codes).values('id'))).select_related('standard_name').values_list('synonym', 'standard_name__standard_name', 'standard_name__source', 'standard_name__source_value'), columns=['Related Name', 'Standard Name', 'Standard Name Source', 'Standard Name Source Value'])
            with BytesIO() as b:
                df.to_excel(b, index=False)
                b.seek(0)
                send_mail_w_attachment((email_address,), 'Biomarker Database Update', 'Attached you will find your recent updates to the Biomarker database.', b.read())
        return HttpResponse('Entries Updated Successfully in Database')


class NCBILookup(View):
    def get(self, request, *args, **kwargs):
        search_term = request.GET.get('query', '')
        gene_id = get_gene_id_from_ncbi(search_term)
        return JsonResponse(get_alternative_names_from_ncbi(gene_id))


class UniprotLookup(View):
    def get(self, request, *args, **kwargs):
        search_term = request.GET.get('query', '')
        return JsonResponse(get_alternative_names_from_uniprot(search_term))


class IndividualStandardName(RetrieveUpdateDestroyAPIView):
    serializer_class = StandardNameSerializer
    queryset = StandardName.objects.all()


class IndividualSynonym(RetrieveUpdateDestroyAPIView):
    serializer_class = BasicSynonymSerializer
    queryset = Synonym.objects.all()


class DatabaseLookup(View):
    def get(self, request, *args, **kwargs):
        search_term = request.GET.get('query', '')
        synonym = Synonym.objects.filter(synonym=search_term).first()
        if synonym is None:
            preferred_name = ''
            other_designations = []
        else:
            preferred_name = synonym.standard_name.standard_name
            other_designations = [x[0] for x in Synonym.objects.filter(standard_name_id=synonym.standard_name_id).values_list('synonym')]
        return JsonResponse({
            'preferred_name': preferred_name,
            'other_designations': other_designations
        })


class DownloadCompleteBiomarkerList(View):
    def get(self, request, *args, **kwargs):
        all_data_df = pd.DataFrame.from_records(Synonym.objects.select_related('standard_name').all().values_list('synonym', 'standard_name__standard_name', 'standard_name__source', 'standard_name__source_value'), columns=['Related Name', 'Standard Name', 'Standard Name Source', 'Standard Name Source Value'])
        with BytesIO() as b:
            # Use the StringIO object as the filehandle.
            writer = pd.ExcelWriter(b, engine='xlsxwriter')
            all_data_df.to_excel(writer, sheet_name='Sheet1', index=False)
            writer.save()
            filename = 'related names'
            content_type = 'application/vnd.ms-excel'
            response = HttpResponse(b.getvalue(), content_type=content_type)
            response['Content-Disposition'] = 'attachment; filename="' + filename + '.xlsx"'
            return response


class ListPreferredNames(ListAPIView):
    serializer_class = StandardNameSerializer
    queryset = StandardName.objects.all().order_by('standard_name')


class ListSynonymNames(ListAPIView):
    serializer_class = SynonymNameSerializer

    def get_queryset(self):
        queryset = Synonym.objects.all()

        # Standard Name
        standard_pk = self.request.query_params.get('preferred_pk', -1)
        standard_name = self.request.query_params.get('preferred_name', '')

        queryset = queryset.filter(standard_name_id=standard_pk, standard_name__standard_name=standard_name).\
            select_related('standard_name')

        return queryset


@method_decorator(csrf_exempt, name='dispatch')
class UpdateDatabaseView(View):
    def post(self, request, *args, **kwargs):
        # Check if file is valid.
        if 'file' in request.FILES.keys():
            file_df = pd.read_excel(request.FILES['file'], skiprows=2)
            lut_dict = file_df.set_index('Assay Lab Analyte Name').to_dict()['Gilead Analyte Name']
            process_test_code_library.delay(lut_dict)
            return HttpResponse(status=204)


@method_decorator(csrf_exempt, name='dispatch')
class GetStandardNames(View):
    def post(self, request, *args, **kwargs):
        body_unicode = request.body.decode('utf-8')
        body = json.loads(body_unicode)['data']
        query_list = body['query'].split('|')
        email_address = body['emailAddress']
        lookup_type = body['lookupType']
        email_standard_names(query_list, lookup_type, email_address)
        return HttpResponse(status=204)


