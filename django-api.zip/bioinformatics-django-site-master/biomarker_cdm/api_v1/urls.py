from django.urls import path, include
from .apiviews import UploadBiomarkersForStandardization, DownloadCompleteBiomarkerList, NCBILookup,\
    ListPreferredNames, ListSynonymNames, DatabaseLookup, IndividualStandardName, IndividualSynonym, \
    UploadUniprotCodesForStandardization, UniprotLookup, UpdateDatabaseView

urlpatterns = [
    path('all-preferred-names/', ListPreferredNames.as_view(), name='all_preferred_names'),
    path('select-synonym-names/', ListSynonymNames.as_view(), name='select_synonym_names'),
    path('ncbi-lookup/', NCBILookup.as_view(), name='ncbi_lookup'),
    path('uniprot-lookup/', UniprotLookup.as_view(), name='uniprot_lookup'),
    path('database-lookup/', DatabaseLookup.as_view(), name='database_lookup'),
    path('individual-standard-name/<int:pk>/', IndividualStandardName.as_view(), name='individual_standard_name'),
    path('individual-synonym/<int:pk>/', IndividualSynonym.as_view(), name='individual_synonym'),
    path('standardize-ncbi/', UploadBiomarkersForStandardization.as_view(), name='upload_biomarkers_ncbi'),
    path('standardize-uniprot/', UploadUniprotCodesForStandardization.as_view(), name='upload_proteins_uniprot'),
    path('download-all/', DownloadCompleteBiomarkerList.as_view(), name='download_excel_biomarkers'),
    path('update-database/', UpdateDatabaseView.as_view(), name='update_database')
]