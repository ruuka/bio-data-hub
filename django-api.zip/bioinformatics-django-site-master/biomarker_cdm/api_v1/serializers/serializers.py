from rest_framework import serializers
from biomarker_cdm import models

class StandardNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.StandardName
        fields = ('standard_name', 'id', 'source')


class BasicSynonymSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Synonym
        fields = ('standard_name_id', 'synonym', 'source', 'id')


class SynonymNameSerializer(serializers.ModelSerializer):
    currentValue = serializers.SerializerMethodField()
    editValue = serializers.SerializerMethodField()
    isEdit = serializers.SerializerMethodField()
    isDelete = serializers.SerializerMethodField()

    def get_currentValue(self, obj):
        return obj.synonym

    def get_editValue(self, obj):
        return obj.synonym

    def get_isEdit(self, obj):
        return False

    def get_isDelete(self, obj):
        return False

    class Meta:
        model = models.Synonym
        fields = ('currentValue', 'editValue', 'isEdit', 'isDelete', 'id')
