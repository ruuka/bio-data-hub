from django.apps import AppConfig


class BiomarkerCdmConfig(AppConfig):
    name = 'biomarker_cdm'
