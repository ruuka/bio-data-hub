from django.db import models


# Create your models here.
class StandardName(models.Model):
    standard_name = models.TextField(db_column='standard_name')
    #source = models.TextField(db_column='source')
    #source_value = models.TextField(db_column='source_value')
    #datetime_added = models.DateTimeField(db_column='datetime_added', auto_now_add=True)
    #datetime_modified = models.DateTimeField(db_column='datetime_modified', auto_now=True)
    #datetime_retired = models.DateTimeField(db_column='datetime_retired', null=True, default=None)

    class Meta:
        db_table = 'standard_name'
        constraints = [
            models.UniqueConstraint(fields=['standard_name'], name='unique biomarker name'),
        ]
        indexes = [
            models.Index(fields=['standard_name']),
        ]



class Synonym(models.Model):
    standard_name = models.ForeignKey(to='StandardName', on_delete=models.CASCADE, related_name='synonyms')
    synonym = models.TextField(db_column='synonym')
    #source = models.TextField(db_column='source')
    #source_value = models.TextField(db_column='source_value')
    #datetime_added = models.DateTimeField(db_column='datetime_added', auto_now_add=True)
    #datetime_modified = models.DateTimeField(db_column='datetime_modified', auto_now=True)
    #datetime_retired = models.DateTimeField(db_column='datetime_retired', null=True, default=None)

    class Meta:
        db_table = 'synonym'
        constraints = [
            models.UniqueConstraint(fields=['synonym'], name='unique biomarker synonym'),
        ]
        indexes = [
            models.Index(fields=['standard_name']),
        ]
