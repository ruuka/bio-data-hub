from django.shortcuts import render
from django.views.generic import View
import BioinformaticsDepartmentWebsite.settings.base_settings as sett


class PublicationView(View):
    def get(self, request, *args, **kwargs):
        context = {
            'publication_list': sett.publication_list,
            'name': 'Publications List',
        }
        return render(request, template_name='publications.html', context=context)
