from .base_settings import *
import os
import redis

DEBUG = False

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql_psycopg2',
        'NAME': os.environ['DATABASE_NAME'],
        'USER': os.environ['RDS_USERNAME'],
        'PASSWORD': os.environ['RDS_PASSWORD'],
        'HOST': os.environ['RDS_HOSTNAME'].split(':')[0],
        'PORT': os.environ['RDS_HOSTNAME'].split(':')[1],
        'CONN_MAX_AGE': 600,
    }
}

CELERY_TASK_ALWAYS_EAGER = False

# Cache Settings
API_CACHE_TTL = 60*60  # To be used for API Cache TTLs (as minutes*60)

COMPRESS_OFFLINE = True  # Boolean that decides if compression should be done outside of the request/response loop. Default is False.

import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

sentry_sdk.init(
    dsn="https://f58f5bf7753d4e1ba7fda02a5ee3a093@o329799.ingest.sentry.io/5325754",
    integrations=[DjangoIntegration()],

    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for performance monitoring.
    # We recommend adjusting this value in production.
    traces_sample_rate=1.0,

    # If you wish to associate users to errors (assuming you are using
    # django.contrib.auth) you may enable sending PII data.
    send_default_pii=True
)
