"""BioinformaticsDepartmentWebsite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.views.generic import TemplateView

admin.site.site_header = "Bioinformatics Data Hub Administration"
admin.site.site_title = "Bioinfo Data Hub Admin Portal"
admin.site.index_title = "Welcome to Bioinformatics Data Hub Admin"

urlpatterns = [
    path('', TemplateView.as_view(template_name='index.html', extra_context={
        'name': 'Clinical Bioinformatics',
        'subtitle': 'A portal to access and analyze Gilead\'s \'omics data.',
    }), name='index'),
    path('api/', include(('api.urls', 'api'), namespace='api')),
    path('biomarker-cdm/', include(('biomarker_cdm.urls', 'biomarker_cdm'), namespace='biomarker_cdm')),
    path('ta/', include(('ta_pages.urls', 'ta_pages'), namespace='ta')),
    path('admin/', admin.site.urls),
    path('publications/', include(('publications.urls', 'publications'), namespace='publications')),
    path('', include(('general_information.urls', 'general_information'), namespace='general_information')),
]

if settings.DEBUG:
    from django.core.cache import cache
    cache.clear()

if settings.DEBUG:
    import debug_toolbar

    urlpatterns = [
        path('__debug__/', include(debug_toolbar.urls)),
    ] + urlpatterns