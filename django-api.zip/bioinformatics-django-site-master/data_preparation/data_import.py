import pandas as pd
import dask.dataframe as dd
import numpy as np
import sqlalchemy
import math
import os
from tqdm import tqdm
from sqlalchemy import distinct, tuple_, cast, REAL
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine

Base = declarative_base()
uri = 'postgresql://postgres:{password}@localhost:5432/bioinfo'.format(password=os.environ['DB_PASSWORD'])
engine = create_engine(uri)


class SubjectTable(Base):
    __table__ = sqlalchemy.Table('subject', Base.metadata, autoload=True, autoload_with=engine)


class StudyTable(Base):
    __table__ = sqlalchemy.Table('study', Base.metadata, autoload=True, autoload_with=engine)


class GeneTable(Base):
    __table__ = sqlalchemy.Table('gene_info', Base.metadata, autoload=True, autoload_with=engine)


class GeneAliasTable(Base):
    __table__ = sqlalchemy.Table('gene_alias', Base.metadata, autoload=True, autoload_with=engine)


class GeneExpressionTable(Base):
    __table__ = sqlalchemy.Table('gene_expression', Base.metadata, autoload=True, autoload_with=engine)


class PathwayTable(Base):
    __table__ = sqlalchemy.Table('pathway_info', Base.metadata, autoload=True, autoload_with=engine)


class PathwayExpressionTable(Base):
    __table__ = sqlalchemy.Table('pathway_expression', Base.metadata, autoload=True, autoload_with=engine)


class DifferentialGeneExpressionTable(Base):
    __table__ = sqlalchemy.Table('differential_gene_expression', Base.metadata, autoload=True, autoload_with=engine)


class DifferentialPathwayExpressionTable(Base):
    __table__ = sqlalchemy.Table('differential_pathway_expression', Base.metadata, autoload=True, autoload_with=engine)


class TreatmentArmTable(Base):
    __table__ = sqlalchemy.Table('treatment_arm', Base.metadata, autoload=True, autoload_with=engine)


class TreatmentComponentTable(Base):
    __table__ = sqlalchemy.Table('treatment_component', Base.metadata, autoload=True, autoload_with=engine)


class BiomarkerTable(Base):
    __table__ = sqlalchemy.Table('biomarker_tests', Base.metadata, autoload=True, autoload_with=engine)


class BiomarkerInfoTable(Base):
    __table__ = sqlalchemy.Table('biomarker_test_info', Base.metadata, autoload=True, autoload_with=engine)


class EfficacyMeasuresTable(Base):
    __table__ = sqlalchemy.Table('efficacy_measures', Base.metadata, autoload=True, autoload_with=engine)


class TCGAExpressionTable(Base):
    __table__ = sqlalchemy.Table('tcgaExpression', Base.metadata, autoload=True, autoload_with=engine)


class GTEXExpressionTable(Base):
    __table__ = sqlalchemy.Table('gtexExpression', Base.metadata, autoload=True, autoload_with=engine)


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def prepare_connection():
    Session = sessionmaker(bind=engine)
    return Session()


def get_or_create(session, model, **kwargs):
    instance = session.query(model).filter_by(**kwargs).first()
    if instance:
        return instance
    else:
        instance = model(**kwargs)
        session.add(instance)
        session.commit()
        return instance


def get_instance(session, model, **kwargs):
    return session.query(model).filter_by(**kwargs).first()


def get_potential_genes():
    session = prepare_connection()
    return set([x[0] for x in session.query(distinct(GeneTable.gene_symbol)).all()])


def load_gene_info_table(gene_expression_df):
    session = prepare_connection()
    unique_genes = set(gene_expression_df['gene_id'])
    for gene_id in tqdm(unique_genes, total=len(unique_genes), desc='Loading Gene Info'):
        gene_entry = get_or_create(session, GeneTable, gene_symbol=gene_id)


def load_study_info_table(study_df):
    session = prepare_connection()
    for row in tqdm(study_df.itertuples(index=False), total=len(study_df), desc='Loading Study Info Data'):
        if hasattr(row, 'name'):
            if pd.isnull(row.name):
                name = ''
            else:
                name = row.name
        else:
            name = ''

        get_or_create(session, StudyTable,
                      study_id=row.study_id,
                      indication=row.indication,
                      therapeutic_area=row.therapeutic_area,
                      name=name)


def load_biomarkers(biomarker_info_df: pd.DataFrame, biomarker_test_df: pd.DataFrame,
                    acceptable_biomarkers_filename: str):
    session = prepare_connection()
    valid_tests_df = pd.read_excel(acceptable_biomarkers_filename, sheet_name='valid_tests')
    unit_conversions_df = pd.read_excel(acceptable_biomarkers_filename, sheet_name='unit_conversions',
                                        index_col='Old Unit')
    name_conversions_df = pd.read_excel(acceptable_biomarkers_filename, sheet_name='name_conversions',
                                        index_col='Original Name')
    unit_change_df = pd.read_excel(acceptable_biomarkers_filename, sheet_name='unit_changes')

    valid_tests_lut = {}
    for row in valid_tests_df.itertuples(index=False):
        valid_tests_lut[(row.name, row.specimen_type)] = row
    unit_conversion_lut = unit_conversions_df.to_dict('index')
    name_conversions_lut = name_conversions_df.to_dict('index')

    unit_change_lut = {}
    for row in unit_change_df.itertuples(index=False):
        unit_change_lut[(row.start_unit, row.end_unit)] = row.multiplication

    merged_biomarker_df = biomarker_test_df.merge(biomarker_info_df, on='test_id')

    biomarker_name_to_id_lut, subject_unique_id_to_pk_lut = {}, {}
    for row in tqdm(merged_biomarker_df.itertuples(index=False), total=len(merged_biomarker_df),
                    desc='Loading Biomarkers'):
        unit = row.unit
        value = row.value
        name = row.name

        if pd.isnull(unit):
            unit = None

        # Correct Unit to Common Value
        if unit in list(unit_conversion_lut.keys()):
            value = value * unit_conversion_lut[unit]['Multiplication']
            unit = unit_conversion_lut[unit]['New Unit']

        # Correct Name to Common Value
        if name in name_conversions_lut.keys():
            name = name_conversions_lut[name]['New Name']

        name_with_specimen = str(row.specimen_type) + ' ' + name

        # Determine if Current Unit for Test is Not the Same as in Database and Correct if Possible
        test_info_instance = get_instance(session, BiomarkerInfoTable, name=name_with_specimen)
        if (test_info_instance is not None) and (not unit == test_info_instance.unit):
            dict_key = (unit, test_info_instance.unit)
            if dict_key in unit_change_lut.keys():
                unit = test_info_instance.unit
                value = value * unit_change_lut[dict_key]
            else:  # Add special cases to convert
                if (str(name_with_specimen) == 'Urine Creatinine') and (str(unit) == 'mmol/L'):
                    unit = 'mg/L'
                    value = value / 8.84
                else:
                    raise ValueError('unit_changes conversion is not specified for ' + str(name_with_specimen)
                                     + ' of type ' + unit + ' to ' + test_info_instance.unit)

        # Find test id if test exists, or create new one if not.
        if name_with_specimen in biomarker_name_to_id_lut.keys():
            test_id = biomarker_name_to_id_lut[name_with_specimen]
        else:
            get_or_create(session, BiomarkerInfoTable,
                          name=name_with_specimen,
                          unit=unit)

            test_info_instance = get_instance(session, BiomarkerInfoTable, name=name_with_specimen, unit=unit)
            test_id = test_info_instance.id
            biomarker_name_to_id_lut[name_with_specimen] = test_id

        # Unique Subject ID
        unique_subject_id = row.unique_subject_id
        if unique_subject_id in subject_unique_id_to_pk_lut.keys():
            subject_pk = subject_unique_id_to_pk_lut[unique_subject_id]
        else:
            subject_pk = session.query(SubjectTable.id).filter(
                SubjectTable.unique_subject_id == unique_subject_id).scalar()
            subject_unique_id_to_pk_lut[unique_subject_id] = subject_pk

        # Correct Missing Days
        if pd.isnull(row.day_number):
            day = None
        else:
            day = row.day_number

        get_or_create(session, BiomarkerTable,
                      time_point=row.week_number,
                      day_time_point=day,
                      test_result=cast(value, REAL),
                      subject_id=subject_pk,
                      lloq=row.lloq,
                      uloq=row.uloq,
                      test_id=test_id)


def load_biomarker_info_table(biomarker_info_df):
    session = prepare_connection()
    for row in tqdm(biomarker_info_df.itertuples(index=False), total=len(biomarker_info_df),
                    desc='Loading Biomarker Info'):
        if row.unit.encode('utf-8') == b'\xc2\xb5g/mL':
            unit = b'\xc2\xb5g/mL'.decode('utf-8')
        else:
            unit = row.unit
        if pd.isnull(row.lloq):
            lloq = None
        else:
            lloq = cast(row.lloq, REAL)
        get_or_create(session, BiomarkerInfoTable,
                      name=row.name,
                      unit=unit,
                      lloq=lloq)


def load_biomarker_test_data(biomarker_test_df, biomarker_info_df):
    session = prepare_connection()
    test_id_lut = session.query(BiomarkerInfoTable.name, BiomarkerInfoTable.id).all()
    test_id_lut = {x[0]: x[1] for x in test_id_lut}
    subject_id_lut = session.query(SubjectTable.unique_subject_id, SubjectTable.id).all()
    subject_id_lut = {x[0]: x[1] for x in subject_id_lut}
    merged_df = biomarker_test_df.merge(biomarker_info_df, on='test_id')
    for row in tqdm(merged_df.itertuples(index=False), total=len(biomarker_test_df), desc='Loading Biomarker Tests'):
        get_or_create(session, BiomarkerTable,
                      time_point=row.week_number,
                      day_time_point=row.day_number,
                      test_result=cast(row.value, REAL),
                      subject_id=subject_id_lut[row.unique_subject_id],
                      test_id=test_id_lut[row.name])


def load_treatment_data(treatment_df):
    session = prepare_connection()
    for row in tqdm(treatment_df.itertuples(index=False), total=len(treatment_df), desc='Loading Treatment Data'):
        # Treatment Arm
        treatment_arm = row.treatment_arm

        # Active Ingredient Name
        if pd.isnull(row.active_name):
            active_name = None
        else:
            active_name = row.active_name

        # Dose
        if hasattr(row, 'dose_mg'):
            if pd.isnull(row.dose_mg):
                dose = None
            else:
                dose = row.dose_mg
            unit = 'mg'
        else:
            if pd.isnull(row.dose):
                dose = None
            else:
                dose = row.dose
            unit = row.dose_unit

        # Description
        if pd.isnull(row.description):
            description = None
        else:
            description = row.description

        # Insert and Get Treatment Arm Record
        treatment_arm_record = get_or_create(session, TreatmentArmTable, preferred_name=treatment_arm)
        treatment_arm_id = treatment_arm_record.id

        # Insert Treatment Record
        treatment_component_record = get_or_create(session, TreatmentComponentTable,
                                                   active_name=active_name,
                                                   treatment_arm_id=treatment_arm_id,
                                                   dose=dose,
                                                   unit=unit,
                                                   description=description)


def load_subject_info_table(demographics_df):
    session = prepare_connection()
    for row in tqdm(demographics_df.itertuples(index=False), total=len(demographics_df),
                    desc='Loading Demographic Data'):
        # Unique Subject Identifier
        unique_subject_id = str(row.unique_subject_id)

        # Study ID
        study_id = row.study_id

        # Sex
        is_male = row.is_male
        if pd.isnull(is_male):
            is_male = None

        # Race
        race = row.race
        if pd.isnull(race):
            race = None

        # Ethnicity
        is_hispanic = row.is_hispanic
        if pd.isnull(is_hispanic):
            is_hispanic = None

        # Healthy Volunteer
        if hasattr(row, 'is_healthy'):
            is_healthy = row.is_healthy
        else:
            is_healthy = False

        # Treatment
        treatment_instance = get_instance(session, TreatmentArmTable, preferred_name=row.treatment_arm)

        # Age
        age_years = row.age_years
        if pd.isnull(age_years):
            age_years = None

        # BMI
        bmi = cast(row.bmi, REAL)

        subject_entry = get_or_create(session, SubjectTable,
                                      unique_subject_id=unique_subject_id,
                                      is_male=is_male,
                                      is_healthy=is_healthy,
                                      race=race,
                                      is_hispanic=is_hispanic,
                                      treatment_arm_id=treatment_instance.id,
                                      age_years=age_years,
                                      bmi=bmi,
                                      study_id=study_id,
                                      )


def load_gene_expression_data(gene_expression_df, check_all=False):
    gene_expression_df['unique_subject_id'] = gene_expression_df['unique_subject_id'].astype(str)
    session = prepare_connection()
    if check_all:
        potential_genes = get_potential_genes()
        subject_pk_lut = {}
        for row in tqdm(gene_expression_df.itertuples(index=False), total=len(gene_expression_df),
                        desc='Loading Gene Expression Data'):
            if row.PARAM in potential_genes:
                # Unique Subject ID
                unique_subject_id = row.USUBJID
                if unique_subject_id in subject_pk_lut.keys():
                    subject_pk = subject_pk_lut[unique_subject_id]
                else:
                    subject_pk = session.query(SubjectTable.id).filter(
                        SubjectTable.unique_subject_id == unique_subject_id).scalar()
                    subject_pk_lut[unique_subject_id] = subject_pk

                # Visit Week
                week_number = row.AVISIT2

                # Gene Symbol
                gene_symbol = row.PARAM

                # Tissue Source
                if row.TissueSource == 'whole-blood':
                    tissue_source = 'Whole Blood'
                else:
                    raise ValueError('Incorrect Tissue Source Value')

                # Log 2 TPM Value
                log_2_tpm = cast(row.AVAL, REAL)

                get_or_create(session, GeneExpressionTable,
                              tissue_source=tissue_source,
                              time_point=week_number,
                              log_2_tpm=log_2_tpm,
                              gene_id=gene_symbol,
                              subject_id=subject_pk)

    else:
        usubjid_to_subj_pk = session.query(SubjectTable.unique_subject_id, SubjectTable.id).all()
        usubjid_to_subj_pk = {x[0]: x[1] for x in usubjid_to_subj_pk}
        approved_genes = session.query(GeneTable.gene_symbol).all()
        approved_genes = [x[0] for x in approved_genes]
        to_sql_df = pd.DataFrame()
        to_sql_df['time_point'] = gene_expression_df['week_number']
        to_sql_df['subject_id'] = gene_expression_df['unique_subject_id'].map(usubjid_to_subj_pk)
        to_sql_df['gene_id'] = gene_expression_df['gene_symbol']
        to_sql_df['tissue_source'] = gene_expression_df['tissue_source']
        to_sql_df['log_2_tpm'] = gene_expression_df['log_2_tpm']
        to_sql_df = to_sql_df[to_sql_df.gene_id.isin(approved_genes)]
        to_sql_df.to_sql('gene_expression', engine, if_exists='append', index=False, chunksize=10000)


def extract_pathway_set_and_name(combined_pathway_name):
    split_pathway = combined_pathway_name.split('_')
    pathway_set = split_pathway[0]
    pathway_name = '_'.join(split_pathway[1:])
    return pathway_set, pathway_name


def load_pathway_info_table(pathway_expression_df):
    session = prepare_connection()
    unique_pathways = set(
        [(x[0], x[1]) for x in zip(pathway_expression_df['pathway_set'], pathway_expression_df['pathway_name'])])
    for pathway_set, pathway_name in tqdm(unique_pathways, total=len(unique_pathways), desc='Loading Pathway Info'):
        pathway_name = pathway_name.replace('_', ' ')
        pathway_entry = get_or_create(session, PathwayTable, pathway_set=pathway_set, pathway_name=pathway_name)


def load_pathway_expression_data(pathway_expression_df, check_all: bool):
    session = prepare_connection()
    if check_all:
        potential_pathways = set([x[0][1:-1] for x in session.query(
            distinct(tuple_(PathwayTable.pathway_set, PathwayTable.pathway_name))).all()])

        subject_pk_lut, pathway_pk_lut = {}, {}
        for row in tqdm(pathway_expression_df.itertuples(index=False), total=len(pathway_expression_df),
                        desc='Loading Pathway Expression Data'):
            pathway_set, pathway_name = row.pathway_set, row.pathway_name
            pathway_name = pathway_name.replace('_', ' ')
            # Unique Subject ID
            unique_subject_id = row.unique_subject_id
            if unique_subject_id in subject_pk_lut.keys():
                subject_pk = subject_pk_lut[unique_subject_id]
            else:
                subject_pk = session.query(SubjectTable.id).filter(
                    SubjectTable.unique_subject_id == unique_subject_id).scalar()
                subject_pk_lut[unique_subject_id] = subject_pk

            # Pathway ID
            if (pathway_set, pathway_name) in pathway_pk_lut.keys():
                pathway_pk = pathway_pk_lut[(pathway_set, pathway_name)]
            else:
                pathway_pk = session.query(PathwayTable.id).filter(
                    PathwayTable.pathway_set == pathway_set, PathwayTable.pathway_name == pathway_name).scalar()
                pathway_pk_lut[(pathway_set, pathway_name)] = pathway_pk

            # Visit Week
            week_number = row.week_number

            # Tissue Source
            tissue_source = row.tissue_source

            # Log 2 TPM Value
            ssgsea = cast(row.ssgsea, REAL)

            get_or_create(session, PathwayExpressionTable,
                          tissue_source=tissue_source,
                          time_point=week_number,
                          ssgsea=ssgsea,
                          pathway_id=pathway_pk,
                          subject_id=subject_pk)
    else:
        # gene_expression_df['pathway_name'] = gene_expression_df['pathway_name'].apply(lambda x: x.replace('_', ' '))
        usubjid_to_subj_pk = session.query(SubjectTable.unique_subject_id, SubjectTable.id).all()
        usubjid_to_subj_pk = {x[0]: x[1] for x in usubjid_to_subj_pk}
        pathway_to_pathway_pk = session.query(PathwayTable.id, PathwayTable.pathway_set,
                                              PathwayTable.pathway_name).all()
        pathway_to_pathway_pk = {(x[1], x[2]): x[0] for x in pathway_to_pathway_pk}
        to_sql_df = pd.DataFrame()
        to_sql_df['time_point'] = pathway_expression_df['week_number']
        to_sql_df['subject_id'] = pathway_expression_df['unique_subject_id'].map(usubjid_to_subj_pk)
        to_sql_df['pathway_id'] = pathway_expression_df.apply(
            lambda x: pathway_to_pathway_pk[(x['pathway_set'], x['pathway_name'].replace('_', ' '))], axis=1)
        to_sql_df['tissue_source'] = pathway_expression_df['tissue_source']
        to_sql_df['ssgsea'] = pathway_expression_df['ssgsea']
        to_sql_df.to_sql('pathway_expression', engine, if_exists='append', index=False, chunksize=10000)


def load_differential_gene_expression_data(differential_gene_expression_df):
    session = prepare_connection()
    potential_genes = get_potential_genes()
    for row in tqdm(differential_gene_expression_df.itertuples(),
                    total=len(differential_gene_expression_df),
                    desc='Loading Differential Gene Expression Data'):
        gene_id = row.gene_id
        if gene_id in potential_genes:
            # Study ID
            study_id = row.study_id

            # Tissue Source
            tissue_source = row.tissue_source

            # Time Points
            first_visit = row.first_time_point
            second_visit = row.second_time_point

            # Minuend Data
            minuend_treatment_instance = get_instance(session, TreatmentArmTable,
                                                      preferred_name=row.minuend_treatment_arm)
            minuend_treatment_id = minuend_treatment_instance.id

            # Subtrahend Data
            if pd.isnull(row.subtrahend_treatment_arm):
                subtrahend_treatment_id = None
            else:
                subtrahend_treatment_instance = get_instance(session, TreatmentArmTable,
                                                             preferred_name=row.subtrahend_treatment_arm)
                subtrahend_treatment_id = subtrahend_treatment_instance.id

            # Lower and Upper Fold Change Confidence Internvals
            if pd.isnull(row.log_fold_change_lower_ci):
                log_fold_change_lower_ci = None
            else:
                log_fold_change_lower_ci = cast(row.log_fold_change_lower_ci, REAL)
            if pd.isnull(row.log_fold_change_upper_ci):
                log_fold_change_upper_ci = None
            else:
                log_fold_change_upper_ci = cast(row.log_fold_change_upper_ci, REAL)

            # Test Results
            log_fc = cast(row.log_fold_change, REAL)
            p_value = cast(row.p_value, REAL)
            fdr_p_value = cast(row.fdr_p_value, REAL)

            get_or_create(session, DifferentialGeneExpressionTable,
                          tissue_source=tissue_source,
                          first_time_point=first_visit,
                          second_time_point=second_visit,
                          gene_id=gene_id,
                          study_id=study_id,
                          minuend_treatment_arm_id=minuend_treatment_id,
                          subtrahend_treatment_arm_id=subtrahend_treatment_id,
                          log_fc=log_fc,
                          log_fc_lower_ci=log_fold_change_lower_ci,
                          log_fc_upper_ci=log_fold_change_upper_ci,
                          p_value=p_value,
                          fdr_p_value=fdr_p_value)


def load_differential_pathway_expression_data(differential_pathway_expression_df):
    session = prepare_connection()
    potential_pathways = set([x[0][1:-1] for x in session.query(
        distinct(tuple_(PathwayTable.pathway_set, PathwayTable.pathway_name))).all()])
    pathway_pk_lut = {}
    for row in tqdm(differential_pathway_expression_df.itertuples(),
                    total=len(differential_pathway_expression_df),
                    desc='Loading Differential Pathway Expression Data'):
        pathway_set, pathway_name = row.pathway_set, row.pathway_name
        pathway_name = pathway_name.replace('_', ' ')

        # Pathway ID
        if (pathway_set, pathway_name) in pathway_pk_lut.keys():
            pathway_pk = pathway_pk_lut[(pathway_set, pathway_name)]
        else:
            pathway_pk = session.query(PathwayTable.id).filter(
                PathwayTable.pathway_set == pathway_set, PathwayTable.pathway_name == pathway_name).scalar()
            pathway_pk_lut[(pathway_set, pathway_name)] = pathway_pk

        # Study ID
        study_id = row.study_id

        # Tissue Source
        tissue_source = row.tissue_source

        # Time Points
        first_visit = row.first_time_point
        second_visit = row.second_time_point

        # Minuend Data
        minuend_treatment_instance = get_instance(session, TreatmentArmTable, preferred_name=row.minuend_treatment_arm)
        minuend_treatment_id = minuend_treatment_instance.id

        # Subtrahend Data
        if pd.isnull(row.subtrahend_treatment_arm):
            subtrahend_treatment_id = None
        else:
            subtrahend_treatment_instance = get_instance(session, TreatmentArmTable,
                                                         preferred_name=row.subtrahend_treatment_arm)
            subtrahend_treatment_id = subtrahend_treatment_instance.id

        # Lower and Upper Fold Change Confidence Internvals
        if pd.isnull(row.log_fold_change_lower_ci):
            log_fold_change_lower_ci = None
        else:
            log_fold_change_lower_ci = cast(row.log_fold_change_lower_ci, REAL)
        if pd.isnull(row.log_fold_change_upper_ci):
            log_fold_change_upper_ci = None
        else:
            log_fold_change_upper_ci = cast(row.log_fold_change_upper_ci, REAL)

        # Test Results
        log_fc = cast(row.log_fold_change, REAL)
        p_value = cast(row.p_value, REAL)
        fdr_p_value = cast(row.fdr_p_value, REAL)

        get_or_create(session, DifferentialPathwayExpressionTable,
                      tissue_source=tissue_source,
                      first_time_point=first_visit,
                      second_time_point=second_visit,
                      pathway_id=pathway_pk,
                      study_id=study_id,
                      minuend_treatment_arm_id=minuend_treatment_id,
                      subtrahend_treatment_arm_id=subtrahend_treatment_id,
                      log_fc=log_fc,
                      log_fc_lower_ci=log_fold_change_lower_ci,
                      log_fc_upper_ci=log_fold_change_upper_ci,
                      p_value=p_value,
                      fdr_p_value=fdr_p_value)


def load_efficacy_measures(efficacy_df):
    session = prepare_connection()

    subject_pk_lut = {}
    for row in tqdm(efficacy_df.itertuples(index=False), total=len(efficacy_df),
                    desc='Loading Efficacy Data'):

        # Unique Subject ID
        unique_subject_id = row.unique_subject_id
        if unique_subject_id in subject_pk_lut.keys():
            subject_pk = subject_pk_lut[unique_subject_id]
        else:
            subject_pk = session.query(SubjectTable.id).filter(
                SubjectTable.unique_subject_id == unique_subject_id).scalar()
            subject_pk_lut[unique_subject_id] = subject_pk

        # Efficacy Measure
        measure_name = row.measure_name

        # Time Point
        time_point = int(row.week_number)

        if pd.isnull(row.value):
            continue

        if row.type_of_measure == 'Binary':
            measure_type = 'bool'
            if row.value == 'Y':
                value = True
            elif row.value == 'N':
                value = False
            else:
                raise ValueError('Incorrect Value in Efficacy Row')
        elif row.type_of_measure == 'Numeric':
            measure_type = 'numeric'
            value = float(row.value)
        else:
            raise ValueError('Incorrect Measure Type')

        get_or_create(session, EfficacyMeasuresTable,
                      subject_id=subject_pk,
                      measure_name=measure_name,
                      time_point=time_point,
                      result={
                          'type': measure_type,
                          'value': value
                      })


def load_gene_alias(gene_alias_df):
    session = prepare_connection()

    subject_pk_lut = {}
    for row in tqdm(gene_alias_df.itertuples(index=False), total=len(gene_alias_df),
                    desc='Loading Gene Alias'):
        # Gene Symbol
        gene_symbol = 'NaN' if pd.isnull(row.gene_symbol) else row.gene_symbol

        # Potential Gene Alias
        gene_alias = None if pd.isnull(row.alias_symbols) else row.alias_symbols

        # Gene Value
        gene_value = row.gene_value

        get_or_create(session, GeneAliasTable,
                      gene_id=gene_value,
                      alias_symbol=gene_alias,
                      gene_value=gene_symbol)


def load_tcga_gtex_data(dataset, flag):
    table = 'tcgaExpression' if flag == 'TCGA' else 'gtexExpression'

    dataset.to_sql(table, uri, if_exists='append', index=False)



if __name__ == '__main__':
    # DATA_LOCATION = 'data_preparation/data/HBV 3892025/'

    # df_treatment = pd.read_csv(DATA_LOCATION + 'treatment.csv')
    # load_treatment_data(df_treatment)

    # df_study = pd.read_csv(DATA_LOCATION + 'study_info.csv')
    # load_study_info_table(df_study)

    # df_demographics = pd.read_csv(DATA_LOCATION + 'demographics.csv')
    # load_subject_info_table(df_demographics)

    # df_efficacy = pd.read_csv(DATA_LOCATION + 'efficacy.csv')
    # load_efficacy_measures(df_efficacy)

    # df_biomarker_test = pd.read_csv(DATA_LOCATION + 'biomarker_test.csv')
    # df_biomarker_info = pd.read_csv(DATA_LOCATION + 'biomarker_info.csv', encoding='utf-8')
    # load_biomarkers(df_biomarker_info, df_biomarker_test, 'data_preparation/Master List Acceptable Biomarker Tests.xlsx')

    # df_pathway_expression = pd.read_csv(DATA_LOCATION + 'pathway_expression.csv')
    # load_pathway_info_table(df_pathway_expression)

    # df_gene_expression = pd.read_csv(DATA_LOCATION + 'gene_expression.csv', low_memory=False)
    # df_gene_expression.rename(columns={'gene_symbol': 'gene_id'}, inplace=True)
    # load_gene_info_table(df_gene_expression)

    # differential_gene_expression_df = pd.read_csv(DATA_LOCATION + 'differential_expression.csv', low_memory=False)
    # load_differential_gene_expression_data(differential_gene_expression_df)

    # differential_pathway_expression_df = pd.read_csv(DATA_LOCATION + 'differential_pathway_expression.csv')
    # load_differential_pathway_expression_data(differential_pathway_expression_df)

    # load_pathway_expression_data(df_pathway_expression, check_all=False)
    # load_gene_expression_data(df_gene_expression, check_all=False)

    # GENE_ALIAS_LOCATION = 'data_preparation/data/gene_alias/'
    # df_gene_alias = pd.read_csv(GENE_ALIAS_LOCATION + 'gene_alias.csv')
    # load_gene_alias(df_gene_alias)

    #tcga_df = dd.read_csv('data_preparation/data/tcga_dask/tcga_raw-*.csv',
    #                      dtype={'Code': 'object',
    #                             'Tissue': 'object',
    #                             'file_name': 'object',
    #                             'project': 'object',
    #                             'projectID': 'object',
    #                             'sampleBarcode': 'object',
    #                             'sample_type': 'object',
    #                             'stage': 'object',
    #                             'type': 'object',
    #                             'study_id': 'object'})
    #gtex_df = dd.read_csv('data_preparation/data/gtex_dask/gtex_raw-*.csv',
    #                      dtype={'Code': 'object',
    #                             'Tissue': 'object',
    #                             'file_name': 'object',
    #                             'project': 'object',
    #                             'projectID': 'object',
    #                             'sampleBarcode': 'object',
    #                             'sample_type': 'object',
    #                             'stage': 'object',
    #                             'study_id': 'object'})
    #load_tcga_gtex_data(tcga_df, 'TCGA')
    #load_tcga_gtex_data(gtex_df, 'GTEX')

    # Selection
    data_location = 'data_preparation/data/selection2/'
    #df_study = pd.read_csv(data_location + 'study.csv')
    df_pathway_info = pd.read_csv(data_location + 'pathway_info.csv')
    df_biomarker_test_info = pd.read_csv(data_location + 'biomarker_test_info.csv')
    df_biomarker_test = pd.read_csv(data_location + 'biomarker_tests.csv')
    # df_ge = pd.read_csv(data_location + 'gene_expression.csv')
    # df_de = pd.read_csv(data_location + 'differential_expression.csv')
    # df_pe = pd.read_csv(data_location + 'pathway_expression.csv')
    # df_subject = pd.read_csv(data_location + 'subject.csv')
    # df_efficacy = pd.read_csv(data_location + 'efficacy.csv')
    # load_study_info_table(df_study)
    # load_subject_info_table(df_subject)
    # load_efficacy_measures(df_efficacy)
    # load_pathway_info_table(df_pathway_info)
    # load_differential_gene_expression_data(df_de)

    #load_gene_expression_data(df_ge)
    #load_pathway_expression_data(df_pe, check_all=False)
    load_biomarkers(df_biomarker_test_info, df_biomarker_test, 'data_preparation/Master List Acceptable Biomarker Tests.xlsx')

