from django.shortcuts import render, redirect
from django.views.generic import View
from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect
from .forms import ContactForm
from django.core.mail import send_mail
from django.views.decorators.csrf import csrf_exempt
import json


class ContactFormSubmission(View):
    @csrf_exempt
    def dispatch(self, request, *args, **kwargs):
        return super(ContactFormSubmission, self).dispatch(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        data = json.loads(request.body.decode('utf-8'))
        send_mail(
            'Contact-Us Form: ' + data['subject'],
            'From: {0} | {1}\nMessage: '.format(data['from_name'], data['from_email']) + data['message'],
            'john.austin@gilead.com',
            ['john.austin@gilead.com'],
            fail_silently=False,
        )
        return HttpResponse(status=204)


# Create your views here.
class ContactUsView(View):
    context = {
        'title': 'Questions or Comments?',
        'subtitle': 'Please feel free to submit the form below, send us an email, or call us.',
    }

    def get(self, request):
        self.context['form'] = ContactForm()
        return render(request, 'contact_us.html', self.context)

    def post(self, request):
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            subject = form.cleaned_data['subject']
            message = form.cleaned_data['message']
            try:
                send_mail(subject + ' FROM ' + name, message, email, ['john.austin@gilead.com'])
            except BadHeaderError:
                return HttpResponse('Invalid Header Found.')
            return redirect('general_information:contact_us_success')
        else:
            self.context['form'] = form
            return render(request, 'contact_us.html', self.context)

class RedisTest(View):
    def get(self, request):
        import redis
        r = redis.Redis(host='app-sec-group-redis.frfsm4.ng.0001.usw2.cache.amazonaws.com', port=6379)
        r.flushall()
        r.flushdb()
        if r.set('t', 5):
            return HttpResponse('Yes, Able to Connect to Redis')
        else:
            return HttpResponse('No, Unable to Connect to Redis')

