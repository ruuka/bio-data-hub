from django.apps import AppConfig


class GeneralInformationConfig(AppConfig):
    name = 'general_information'
