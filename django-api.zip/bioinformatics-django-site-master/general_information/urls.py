from django.urls import path, include
from django.views.generic import TemplateView
from .views import ContactUsView, RedisTest

urlpatterns = [
    path('contact-us/success/', TemplateView.as_view(template_name='contact_us_success.html', extra_context={
        'name': 'Success',
        'subtitle': 'Your contact form was successfully submitted.'
    }), name='contact_us_success'),
    path('contact-us/', ContactUsView.as_view(), name='contact_us'),
    path('faq/', TemplateView.as_view(template_name='faq.html', extra_context={
        'name': 'Frequently Asked Questions',
        'subtitle': 'Your questions, answered.'
    }), name='faq'),
    path('redis-test/', RedisTest.as_view(), name='redis_test'),
]
