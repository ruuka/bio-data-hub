from django.apps import AppConfig


class TaPagesConfig(AppConfig):
    name = 'ta_pages'
