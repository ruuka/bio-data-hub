from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    path('inflammation/', TemplateView.as_view(template_name='ta_application.html', extra_context={
        'name': 'Inflammation',
        'subtitle': 'Data Visualization',
    }), name='inflammation_ta_app'),
    path('oncology/', TemplateView.as_view(template_name='ta_application.html', extra_context={
            'name': 'Oncology',
            'subtitle': 'Data Visualization',
        }), name='oncology_ta_app'),
    path('virology/', TemplateView.as_view(template_name='ta_application.html', extra_context={
            'name': 'Virology',
            'subtitle': 'Data Visualization',
        }), name='virology_ta_app'),
]
