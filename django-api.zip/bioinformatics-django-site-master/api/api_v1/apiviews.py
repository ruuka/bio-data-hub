from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from api import models
from .serializers.gene_expression_serializers import GeneExpressionSerializer, PossibleGeneNamesSerializer, \
    PlotOptionsGeneExpressionSerializer, PossibleGeneAliasSerializer, IndividualGeneExpressionSerializer, \
    GeneMetadataSerializer
from .serializers.pathway_expression_serializers import PathwayExpressionSerializer, \
    PlotOptionsPathwayExpressionSerializer, PlotOptionsPathwayOptionsSerializer
from .serializers.differential_gene_expression_serializers import DifferentialGeneExpressionSerializer, \
    PlotOptionsDifferentialGeneExpressionSerializer
from .serializers.base_serializers import GeneSerializer, PathwaySerializer, StudySerializer, DemographicsSerializer, \
    StudyDataOptionsSerializer, EfficacyMeasureOptionsSerializer, DemographicsAndIDSerializer
from .serializers.biomarker_serializers import PossibleBiomarkerNamesSerializer, PlotOptionsBiomarkerSerializer, \
    BiomarkerSerializer, BiomarkerCorrelationScatterplotSerializer, BiomarkerMetadataSerializer, \
    DemographicMetadataSerializer
from .serializers.public_dataset_serializer import TCGASerializer, GTEXSerializer
from .serializers.custom_serializers import CustomCategoricalSerializer, CustomNumericalSerializer
from django.db.models import Prefetch, Case, When, F
from django.utils.decorators import method_decorator
from django.views.decorators.cache import cache_page
from django.views.generic import View
from django.conf import settings
import BioinformaticsDepartmentWebsite.settings.base_settings as sett
from django.http import JsonResponse
import json
import pandas as pd
import numpy as np
from scipy.cluster.hierarchy import ward, leaves_list
from scipy.spatial.distance import pdist
from .covid19.search_helper_functions import get_avg_vector


class BiomarkerView(ListAPIView):
    """
    This is an API endpoint to **GET** biomarker data. This data is returned in a format most convenient for
        grouped box plots or violin plots.

    ## Query Parameters:
        biomarker: biomarker names.
            This can be a single value or a list of values separated by commas.
            default value: 'Serum Adiponectin'

        study: study number to select filter subjects by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-223' aka AS Phase 2 trial

        week: time points (in weeks) to filter test results by.
            This is a single value or a list of values separated by commas. Each value should be an integer.
            default value: 'All'

        effname: Efficacy name measure to consider subject as a responder or non-responder
            This is a single value
            default value: ACR20

        effweek: Week when efficacy measure is considered.
            This is a single value
            default value: 12

    ### Responder Status
        true: subject responded according to efficacy measure
        false: subject did not respond according to efficacy measure
        null: subject did not have an efficacy measure result at the specified time
    """
    serializer_class = BiomarkerSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(BiomarkerView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()
        # Biomarker Name
        biomarker_name = str(self.request.query_params.get('biomarker', 'Serum Adiponectin'))
        biomarker_name = biomarker_name.split(',')
        biomarker_name = [x.replace('|||', ',') for x in biomarker_name]

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-223')
        study_id = study_id.split(',')

        # Week Number
        query_week = self.request.query_params.get('week', 'All')

        # Efficacy Time Point
        eff_week = self.request.query_params.get('effweek', 12)

        # Efficacy Measure
        eff_name = self.request.query_params.get('effname', 'ACR20')

        treatments = models.Study.objects.select_related('study')
        tests = models.BiomarkerTest.objects.select_related('test')
        efficacy = models.EfficacyMeasures.objects.all()
        if query_week is not 'All':
            if isinstance(query_week, str):
                weeks = [int(x) for x in query_week.split(',')]
            else:
                weeks = [query_week]
            queryset = queryset.filter(biomarker_tests__test__name__in=biomarker_name,
                                       biomarker_tests__time_point__in=weeks,
                                       study_id__in=study_id).distinct()
            queryset = queryset.prefetch_related(Prefetch('biomarker_tests',
                                                          queryset=tests.filter(
                                                              test__name__in=biomarker_name,
                                                              time_point__in=weeks), to_attr='test_results'
                                                          )).select_related('treatment_arm') \
                .prefetch_related(Prefetch('efficacy_measures', queryset=efficacy.filter(
                    measure_name=eff_name, time_point=eff_week)))
            queryset = queryset.select_related('study')
        else:
            queryset = queryset.filter(biomarker_tests__test__name__in=biomarker_name,
                                       study_id__in=study_id).distinct()
            queryset = queryset.prefetch_related(Prefetch('biomarker_tests',
                                                          queryset=tests.filter(
                                                              test__name__in=biomarker_name), to_attr='test_results'
                                                          )).select_related('treatment_arm') \
                .prefetch_related(Prefetch('efficacy_measures', queryset=efficacy.filter(
                measure_name=eff_name, time_point=eff_week)))

        return queryset.order_by('biomarker_tests__time_point')


class GeneExpressionView(ListAPIView):
    """
    This is an API endpoint to **GET** gene expression data. This data is returned in a format most convenient for
        grouped box plots or violin plots.

    ## Query Parameters:
        gene: gene id names.
            This can be a single value or a list of values separated by commas.
            default value: 'NOC2L'

        tissue: tissue type where RNA-seq sample was acquired.
            This is a single value or a list of values separated by commas.
            default value: 'Whole Blood'

        study: study number to select filter subjects by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-211' aka Fitzroy trial

        week: time points (in weeks) to filter test results by.
            This is a single value or a list of values separated by commas. Each value should be an integer.
            default value: 0 aka Baseline

        effname: Efficacy name measure to consider subject as a responder or non-responder
            This is a single value
            default value: ACR20

        effweek: Week when efficacy measure is considered.
            This is a single value
            default value: 12

    ### Responder Status
        true: subject responded according to efficacy measure
        false: subject did not respond according to efficacy measure
        null: subject did not have an efficacy measure result at the specified time
    """
    serializer_class = GeneExpressionSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(GeneExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()
        # Gene Id
        gene_id = str(self.request.query_params.get('gene', 'NOC2L'))
        gene_id = gene_id.split(',')

        # Tissue Type
        tissue_type = self.request.query_params.get('tissue', 'Whole Blood')
        tissue_type = tissue_type.split(',')

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')

        # Week Number
        query_week = self.request.query_params.get('week', None)
        if query_week is not None:
            if isinstance(query_week, str):
                weeks = [int(x) for x in query_week.split(',')]
            else:
                weeks = [query_week]
        else:
            weeks = [0]  # Default Value

        # Efficacy Time Point
        eff_week = self.request.query_params.get('effweek', 12)

        # Efficacy Measure
        eff_name = self.request.query_params.get('effname', 'ACR20')

        queryset = queryset.filter(gene_expressions__gene_id__in=gene_id,
                                   gene_expressions__tissue_source__in=tissue_type,
                                   gene_expressions__time_point__in=weeks,
                                   study_id__in=study_id).distinct()

        # Prefetch to reduce number of lookups. If this is done within the serializer, it results in many lookups.
        queryset = queryset.prefetch_related(Prefetch('gene_expressions', models.GeneExpression.objects.filter(
            gene_id__in=gene_id, tissue_source__in=tissue_type, time_point__in=weeks), to_attr='test_results'
                                                      )).select_related('treatment_arm').prefetch_related(
            Prefetch('efficacy_measures',
                     queryset=models.EfficacyMeasures.objects.all()
                     .filter(measure_name=eff_name,
                             time_point=eff_week)))

        return queryset


class GeneExpressionMetadataView(ListAPIView):
    """
    This is an API endpoint to **GET** gene expression metadata. This data is the time points and treatment options for
    gene expression data for use in conjunction with other end points.

    ## Query Parameters:
        study: study number to select filter subjects by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-211' aka Fitzroy trial
    """
    serializer_class = GeneMetadataSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(GeneExpressionMetadataView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.MaterializedGeneMetadataSummaryOptions.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')

        queryset = queryset.filter(study_id__in=study_id)

        return queryset


class BiomarkerMetadataView(ListAPIView):
    """
    This is an API endpoint to **GET** biomarker metadata. This data is the time points and treatment options for
    gene expression data for use in conjunction with other end points.

    ## Query Parameters:
        study: study number to select filter subjects by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-211' aka Fitzroy trial
    """
    serializer_class = BiomarkerMetadataSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(BiomarkerMetadataView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.BiomarkerTest.objects.select_related('subject').values('time_point',
                                                                                 'subject__treatment_arm__preferred_name').all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')

        queryset = queryset.filter(subject__study_id__in=study_id).distinct()

        return queryset


class PathwayExpressionView(ListAPIView):
    """
    This is an API endpoint to GET pathway expression data. This data is returned in a format most convenient for
        grouped box plots or violin plots.

        Query Parameters:
            pathway_set: pathway set name.
                This can be a single value.
                default value: 'HALLMARK'

            pathway_name: pathway name.
                This can be a single value or a list separate by commas.
                default value: 'APICAL SURFACE'

            tissue: tissue type where RNA-seq sample was acquired.
                This is a single value.
                default value: 'Whole Blood'

            study: study number to select filter subjects by.
                This is a single value or a list of values separated by commas.
                default value: 'GLPG0634-CL-211' aka Fitzroy trial

            week: time points (in weeks) to filter test results by.
                This is a single value or a list of values separated by commas. Each value should be an integer.
                default value: 0 aka Baseline

            effname: Efficacy name measure to consider subject as a responder or non-responder
            This is a single value
            default value: ACR20

            effweek: Week when efficacy measure is considered.
                This is a single value
                default value: 12

        ### Responder Status
            true: subject responded according to efficacy measure
            false: subject did not respond according to efficacy measure
            null: subject did not have an efficacy measure result at the specified time
    """
    serializer_class = PathwayExpressionSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PathwayExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()
        # Pathway
        pathway_set = str(self.request.query_params.get('pathway_set', 'HALLMARK'))
        pathway_name = str(self.request.query_params.get('pathway_name', 'APICAL SURFACE'))
        pathway_name = pathway_name.split(',')

        # Tissue Type
        tissue_type = self.request.query_params.get('tissue', 'Whole Blood')

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')

        # Week Number
        query_week = self.request.query_params.get('week', None)
        if query_week is not None:
            if isinstance(query_week, str):
                weeks = [int(x) for x in query_week.split(',')]
            else:
                weeks = [query_week]
        else:
            weeks = [0]  # Default Value

        # Efficacy Time Point
        eff_week = self.request.query_params.get('effweek', 12)

        # Efficacy Measure
        eff_name = self.request.query_params.get('effname', 'ACR20')

        efficacy = models.EfficacyMeasures.objects.all()

        queryset = queryset.filter(pathway_expressions__pathway__pathway_set=pathway_set,
                                   pathway_expressions__pathway__pathway_name__in=pathway_name,
                                   pathway_expressions__tissue_source=tissue_type,
                                   pathway_expressions__time_point__in=weeks,
                                   study_id__in=study_id).distinct()

        # Prefetch to reduce number of lookups. If this is done within the serializer, it results in many lookups.
        queryset = queryset.prefetch_related(Prefetch(
            'pathway_expressions',
            queryset=models.PathwayExpression.objects.filter(
                pathway__pathway_set=pathway_set,
                pathway__pathway_name__in=pathway_name,
                tissue_source=tissue_type,
                time_point__in=weeks).select_related('pathway'), to_attr='test_results'
        )).select_related('treatment_arm').prefetch_related(Prefetch('efficacy_measures', queryset=efficacy.filter(
            measure_name=eff_name, time_point=eff_week)))

        return queryset


class GeneView(ListAPIView):
    serializer_class = GeneSerializer
    queryset = models.Gene.objects.all()

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(GeneView, self).dispatch(*args, **kwargs)
    # TODO Allow filtering by specific genes


class PossibleGeneNamesView(ListAPIView):
    serializer_class = PossibleGeneNamesSerializer
    queryset = models.Gene.objects.values('gene_symbol').all()

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        return Response(queryset.values_list('gene_symbol', flat=True))

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PossibleGeneNamesView, self).dispatch(*args, **kwargs)


class PossibleGeneAliasView(ListAPIView):
    serializer_class = PossibleGeneAliasSerializer

    # queryset = models.GeneAlias.objects.all()

    def get_queryset(self):
        queryset = models.GeneAlias.objects.all()

        # Query like statement for gene alias to limit information
        query = self.request.query_params.get('query', '')
        queryset = queryset.filter(gene_value__icontains=query)
        return queryset


class PossibleBiomarkerNamesView(ListAPIView):
    serializer_class = PossibleBiomarkerNamesSerializer

    def get_queryset(self):
        queryset = models.BiomarkerTestInfo.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-223')
        study_id = study_id.split(',')
        queryset = queryset.filter(biomarker_test_instances__subject__study__in=study_id)

        # Limit to Only Information Needed
        queryset = queryset.only('name', 'unit').distinct('name', 'unit')
        return queryset

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PossibleBiomarkerNamesView, self).dispatch(*args, **kwargs)


class PlotOptionsGeneExpressionView(ListAPIView):
    """
    This is an API endpoint to GET gene expression plot options.

        Query Parameters:
            ta: therapeutic area to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'Inflammation'
        """
    serializer_class = PlotOptionsGeneExpressionSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PlotOptionsGeneExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.MaterializedGeneExpressionPlotOptions.objects.all()

        # TA
        therapeutic_area = self.request.query_params.get('ta', 'Inflammation,Oncology')
        therapeutic_area = therapeutic_area.split(',')

        queryset = queryset.filter(therapeutic_area__in=therapeutic_area)

        return queryset


class PlotOptionsBiomarkerView(ListAPIView):
    """
    This is an API endpoint to GET biomarker plot options.

        Query Parameters:
            study: study number to select filter subjects by.
                This is a single value or a list of values separated by commas.
                default value: 'GLPG0634-CL-223' aka AS Ph. 2 trial
    """
    serializer_class = PlotOptionsBiomarkerSerializer

    def get_queryset(self):
        queryset = models.BiomarkerTest.objects.all()

        # TA
        study = self.request.query_params.get('study', 'GLPG0634-CL-223')
        study = study.split(',')

        queryset = queryset.filter(subject__study_id__in=study)

        queryset = queryset.only('subject__study__study_id', 'time_point', 'test__name', 'test__unit').distinct(
            'subject__study__study_id', 'time_point', 'test__name', 'test__unit').select_related(
            'subject').select_related('subject__study').select_related('test')

        return queryset

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PlotOptionsBiomarkerView, self).dispatch(*args, **kwargs)


class PathwayView(ListAPIView):
    serializer_class = PathwaySerializer
    queryset = models.Pathway.objects.all()

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PathwayView, self).dispatch(*args, **kwargs)
    # TODO Allow filtering by specific pathways


class DemographicsView(ListAPIView):
    """
    This is an API endpoint to GET demographics data.

        Query Parameters:
            study: study IDs to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'GLPG0634-CL-211'

            sex: sex to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'

            race: race to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'

            ethnicity: ethnicity to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'

            agebinned: age bin to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'
    """
    serializer_class = DemographicsSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(DemographicsView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')
        queryset = queryset.filter(study_id__in=study_id)

        # Sex
        sex = self.request.query_params.get('sex', 'All')
        sex = sex.split(',')
        if 'All' not in sex:
            is_male = []
            for indiv_sex in sex:
                is_male.append(models.Subject.reverse_sex(indiv_sex))
            queryset = queryset.filter(is_male__in=is_male)

        # Race
        race = self.request.query_params.get('race', 'All')
        race = race.split(',')
        if 'All' not in race:
            queryset = queryset.filter(race__in=race)

        # Ethnicity
        ethnicity = self.request.query_params.get('ethnicity', 'All')
        ethnicity = ethnicity.split(',')
        if 'All' not in ethnicity:
            is_hispanic = []
            for indiv_ethnicity in ethnicity:
                is_hispanic.append(models.Subject.reverse_ethnicity(indiv_ethnicity))
            queryset = queryset.filter(is_hispanic__in=is_hispanic)

        # Age Binned
        age_binned = self.request.query_params.get('agebinned', 'All')
        age_binned = age_binned.split(',')
        if 'All' not in age_binned:
            acceptable_ages = []
            for indiv_age_range in age_binned:
                acceptable_ages.extend(models.Subject.reverse_age_binned(indiv_age_range))
            queryset = queryset.filter(age_years__in=acceptable_ages)
        return queryset


class DemographicsAndIDView(ListAPIView):
    """
    This is an API endpoint to GET demographics data.

        Query Parameters:
            study: study IDs to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'GLPG0634-CL-211'

            sex: sex to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'

            race: race to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'

            ethnicity: ethnicity to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'

            agebinned: age bin to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'All'
    """
    serializer_class = DemographicsAndIDSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(DemographicsAndIDView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')
        queryset = queryset.filter(study_id__in=study_id)

        # Sex
        sex = self.request.query_params.get('sex', 'All')
        sex = sex.split(',')
        if 'All' not in sex:
            is_male = []
            for indiv_sex in sex:
                is_male.append(models.Subject.reverse_sex(indiv_sex))
            queryset = queryset.filter(is_male__in=is_male)

        # Race
        race = self.request.query_params.get('race', 'All')
        race = race.split(',')
        if 'All' not in race:
            queryset = queryset.filter(race__in=race)

        # Ethnicity
        ethnicity = self.request.query_params.get('ethnicity', 'All')
        ethnicity = ethnicity.split(',')
        if 'All' not in ethnicity:
            is_hispanic = []
            for indiv_ethnicity in ethnicity:
                is_hispanic.append(models.Subject.reverse_ethnicity(indiv_ethnicity))
            queryset = queryset.filter(is_hispanic__in=is_hispanic)

        # Age Binned
        age_binned = self.request.query_params.get('agebinned', 'All')
        age_binned = age_binned.split(',')
        if 'All' not in age_binned:
            acceptable_ages = []
            for indiv_age_range in age_binned:
                acceptable_ages.extend(models.Subject.reverse_age_binned(indiv_age_range))
            queryset = queryset.filter(age_years__in=acceptable_ages)
        return queryset


class DemographicsTimeTreatmentView(ListAPIView):
    """
    This is an API endpoint to **GET** time and treatment metadata.
    This data is the time points and treatment options for
    gene expression data for use in conjunction with other end points.

    ## Query Parameters:
        study: study number to select filter subjects by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-211' aka Fitzroy trial
    """
    serializer_class = DemographicMetadataSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(DemographicsTimeTreatmentView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.BiomarkerTest.objects.select_related('subject').values('time_point',
                                                                                 'subject__treatment_arm__preferred_name',
                                                                                 'subject__id').distinct()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')

        queryset = queryset.filter(subject__study_id__in=study_id)
        return queryset


class StudyView(ListAPIView):
    serializer_class = StudySerializer
    queryset = models.Study.objects.all()

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(StudyView, self).dispatch(*args, **kwargs)
    # TODO Allow filtering by specific study


class DifferentialGeneExpressionView(ListAPIView):
    """
    This is an API endpoint to **GET** differential gene expression data. This data is returned in a format most convenient for
        volcano plots.

    ## Query Parameters:
        tissue: tissue type where RNA-seq sample was acquired.
            This is a single value.
            default value: 'Whole Blood'

        study: study number to select filter subjects by.
            This is a single value.
            default value: 'GLPG0634-CL-211' aka Fitzroy trial

        first_week: time points (in weeks) to filter test results by.
            This is a single value.
            default value: 0 aka Baseline

        second_week: time points (in weeks) to filter test results by.
            This is a single value.
            default value: 10

        min_treatment: treatment id for minuend.
            This is a single value.
            default value: 2 aka Filgotinib, 200 mg

        sub_treatment: treatment id for subtrahend.
            This is a single value.
            default value: None
    """
    serializer_class = DifferentialGeneExpressionSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(DifferentialGeneExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Study.objects.all()

        # Tissue Type
        tissue_type = self.request.query_params.get('tissue', 'Whole Blood')

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')

        # Week Numbers
        first_query_week = self.request.query_params.get('first_week', 0)
        second_query_week = self.request.query_params.get('second_week', 10)

        # Treatment Arms
        minuend_treatment_name = self.request.query_params.get('min_treatment', '')
        minuend_treatment_name = minuend_treatment_name.replace('|||', ',').replace('^^^', '+')
        subtrahend_treatment_name = self.request.query_params.get('sub_treatment', None)
        if isinstance(subtrahend_treatment_name, str):
            subtrahend_treatment_name = subtrahend_treatment_name.replace('|||', ',').replace('^^^', '+')

        queryset = queryset.filter(study_id=study_id)

        # Prefetch to reduce number of lookups. If this is done within the serializer, it results in many lookups.
        queryset = queryset.prefetch_related(Prefetch(
            'differential_gene_expressions',
            queryset=models.DifferentialGeneExpression.objects.filter(
                minuend_treatment_arm__preferred_name=minuend_treatment_name,
                subtrahend_treatment_arm__preferred_name=subtrahend_treatment_name,
                tissue_source=tissue_type,
                first_time_point=first_query_week,
                second_time_point=second_query_week,
                study_id=study_id)
        ))
        return queryset


class PlotOptionsDifferentialGeneExpressionView(ListAPIView):
    """
    This is an API endpoint to GET differential gene expression plot options data.

    ##Query Parameters:
        study: study IDs to filter by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-211'
    """
    serializer_class = PlotOptionsDifferentialGeneExpressionSerializer

    def get_queryset(self):
        queryset = models.DifferentialGeneExpression.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')
        queryset = queryset.filter(study_id__in=study_id)

        queryset = queryset.select_related('minuend_treatment_arm').select_related('subtrahend_treatment_arm')

        # Limit to Only Information Needed
        queryset = queryset \
            .only('study_id',
                  'tissue_source',
                  'first_time_point',
                  'second_time_point',
                  'minuend_treatment_arm__preferred_name',
                  'subtrahend_treatment_arm__preferred_name') \
            .distinct('study_id',
                      'tissue_source',
                      'first_time_point',
                      'second_time_point',
                      'minuend_treatment_arm__preferred_name',
                      'subtrahend_treatment_arm__preferred_name')
        return queryset


class StudyDataPlotOptionsView(ListAPIView):
    """
    This is an API endpoint to GET the study data options available.great
    """
    serializer_class = StudyDataOptionsSerializer
    queryset = models.MaterializedStudyDataOptions.objects.all().order_by('therapeutic_area')

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(StudyDataPlotOptionsView, self).dispatch(*args, **kwargs)
    # TODO Allow filtering by specific pathways


class EfficacyMeasureOptionsView(ListAPIView):
    """
    This is an API endpoint to GET efficacy measure options for a set of studies.

    ##Query Parameters:
        study: study IDs to filter by.
            This is a single value or a list of values separated by commas.
            default value: 'GS-US-417-0301'

        binary: Whether to filter to binary response variables only
            This is a single value.
            default value: True. Any other value besides True will include all effifacy measures.
    """
    serializer_class = EfficacyMeasureOptionsSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(EfficacyMeasureOptionsView, self).dispatch(*args, **kwargs)

    # TODO Allow filtering by specific pathways

    def get_queryset(self):
        queryset = models.EfficacyMeasures.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GS-US-417-0301')
        study_id = study_id.split(',')

        # Binary
        binary = self.request.query_params.get('binary', 'True')
        if binary == 'True':
            binary = 'bool'
        else:
            binary = False

        queryset = queryset.filter(subject__study_id__in=study_id, result__type=binary)

        queryset = queryset.only('measure_name', 'time_point').distinct('measure_name', 'time_point')

        return queryset


def PublicationView(request):
    return JsonResponse(json.loads(sett.publication_list.to_json(orient='records')), safe=False)


class BiomarkerCorrelation(View):
    def get(self, request, *args, **kwargs):
        def perform_clustering(df):
            row_linkage = ward(pdist(df.values))
            new_row_order = leaves_list(row_linkage)
            row_list_sorted = [df.index[i] for i in new_row_order]

            col_linkage = ward(pdist(df.values.transpose()))
            new_col_order = leaves_list(col_linkage)
            col_list_sorted = [df.columns[i] for i in new_col_order]

            df = df.reindex(row_list_sorted)
            df = df[col_list_sorted]
            return df

        # Study ID
        study_id = request.GET.get('study', 'GS-US-417-0301')
        study_id = study_id.split(',')[0]

        # Time Point
        week = request.GET.get('week', 0)

        # Comparisons
        comparisons = request.GET.get('comparisons', 'sex,age')
        comparisons = comparisons.split(',')

        biomarker_queryset = models.Subject.objects.all()
        biomarker_queryset = biomarker_queryset.filter(study_id=study_id, biomarker_tests__time_point=week)
        biomarker_queryset = biomarker_queryset.prefetch_related(
            Prefetch('biomarker_tests', models.BiomarkerTest.objects.all()
                     .filter(time_point=week)
                     .select_related('test')))

        efficacy_queryset = models.Subject.objects.all().filter(study_id=study_id)
        efficacy_queryset = efficacy_queryset.prefetch_related(
            Prefetch('efficacy_measures', models.EfficacyMeasures.objects.all()))

        subject_queryset = models.Subject.objects.all().filter(study_id=study_id)

        def convert_efficacy_result(val):
            if val is True:
                return 1
            elif val is False:
                return 0
            else:
                return val

        biomarker_df = pd.DataFrame(
            biomarker_queryset.values('id', 'biomarker_tests__test_result', 'biomarker_tests__test__name'))
        efficacy_df = pd.DataFrame(
            efficacy_queryset.values('id', 'efficacy_measures__measure_name', 'efficacy_measures__result__value',
                                     'efficacy_measures__time_point'))
        efficacy_df['efficacy_measures__result__value'] = efficacy_df['efficacy_measures__result__value'].apply(
            convert_efficacy_result)
        efficacy_df['eff_compound_name'] = efficacy_df['efficacy_measures__measure_name'] + ' at ' + efficacy_df[
            'efficacy_measures__time_point'].astype(str) + ' Weeks'
        subject_df = pd.DataFrame(
            subject_queryset.values('id', 'is_male', 'is_hispanic', 'age_years', 'bmi')).set_index('id')

        biomarker_df = biomarker_df.pivot(index='id', columns='biomarker_tests__test__name',
                                          values='biomarker_tests__test_result')
        efficacy_df = efficacy_df.pivot(index='id', columns='eff_compound_name',
                                        values='efficacy_measures__result__value')

        merged_df = subject_df.join([biomarker_df, efficacy_df], how='inner')
        if np.nan in merged_df.columns:
            merged_df.drop(columns=[np.nan], inplace=True)

        correlations = merged_df.corr()  # By default this is pearson's correlation
        correlations.fillna(0, inplace = True) # Deal with ultra sparsity issues

        # Select Only Rows that are Biomarkers and Columns that are Efficacy or Subject Correlations
        columns_to_include = [x for x in list(efficacy_df.columns) + list(subject_df.columns) if
                              x in correlations.columns]
        correlations = correlations[columns_to_include]
        correlations = correlations.loc[correlations.index.isin(biomarker_df.columns)]

        correlations.dropna(how='all', axis=0,
                            inplace=True)  # Drop any empty correlations (i.e. no data for that column
        correlations.dropna(how='all', axis=1,
                            inplace=True)  # Drop any empty correlations (i.e. no data for that column
        correlations = perform_clustering(correlations)

        correlations.rename(columns={'is_male': 'Sex', 'age_years': 'Age', 'bmi': 'BMI', 'is_hispanic': 'Hispanic'},
                            inplace=True)

        data = {
            'z': np.flip(correlations.values).tolist(),
            'x': list(correlations.columns)[::-1],
            'y': list(correlations.index)[::-1],
            'type': 'heatmap',
            'colorscale': 'RdBu',
            'zmin': '-1',
            'zmax': '1',
            'hovertemplate': '%{y}' +
                             '<br>%{x}' +
                             '<br><b>Correlation: %{z:.2f}</b>' +
                             '<extra></extra>',
            # 'showscale': False,
        }

        return JsonResponse(data)


class BiomarkerCorrelationScatterplotView(ListAPIView):
    serializer_class = BiomarkerCorrelationScatterplotSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(BiomarkerCorrelationScatterplotView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        # Study ID
        study_id = self.request.query_params.get('study', 'GS-US-417-0301')
        study_id = study_id.split(',')[0]

        # Time Point
        week = self.request.query_params.get('week', 0)

        # Biomarker Name
        biomarker_name = str(self.request.query_params.get('biomarker', 'Serum Adiponectin'))

        # Measure Name
        measure_name = str(self.request.query_params.get('measure_name', 'Sex'))
        if measure_name == 'Sex':
            measure_name = 'sex'
        elif measure_name == 'Age':
            measure_name = 'age_years'
        elif measure_name == 'BMI':
            measure_name = 'bmi'
        elif measure_name == 'Hispanic':
            measure_name = 'is_hispanic'

        # Measure Type
        measure_type = str(self.request.query_params.get('measure_type', 'efficacy'))

        # Measure Time Point
        measure_week = self.request.query_params.get('measure_week', 0)

        queryset = models.BiomarkerTest.objects.all()

        queryset = queryset.filter(subject__study_id=study_id,
                                   time_point=week,
                                   test__name=biomarker_name,
                                   test_result__isnull=False)

        if measure_type == 'efficacy':
            queryset = queryset.filter(subject__efficacy_measures__measure_name=measure_name,
                                       subject__efficacy_measures__time_point=measure_week) \
                .prefetch_related('subject__efficacy_measures').annotate(
                measure=F('subject__efficacy_measures__result'))

        elif measure_type == 'demographic':
            if measure_name == 'sex':
                queryset = queryset.filter(subject__is_male__isnull=False).annotate(measure=F('subject__is_male'))
            elif measure_name == 'age_years':
                queryset = queryset.filter(subject__age_years__isnull=False).annotate(measure=F('subject__age_years'))
            elif measure_name == 'bmi':
                queryset = queryset.filter(subject__bmi__isnull=False).annotate(measure=F('subject__bmi'))
            elif measure_name == 'is_hispanic':
                queryset = queryset.filter(subject__is_hispanic__isnull=False).annotate(
                    measure=F('subject__is_hispanic'))

        return queryset.values('measure', 'test_result', 'test__unit')


class DeepSearchPapers(View):
    def get(self, request, *args, **kwargs):
        search_query = request.GET.get('query', 'COVID-19')
        search_vector = get_avg_vector(search_query, sett.W2V_MODEL, sett.TFIDF_MODEL, lemmatize=False)
        closest_passages, distances = sett.ANNOY_MODEL.get_nns_by_vector(search_vector, 40, include_distances=True)
        # print(closest_passages)
        passage_dist_lut = {x: y for x, y in zip(closest_passages, distances)}
        search_result_from_db = models.COVID19Passage.objects.select_related('paper') \
            .values('text', 'paper__doi_url', 'paper__title', 'paper__abstract', 'paper__journal', 'paper__authors',
                    'paper__year', 'id').filter(id__in=closest_passages)
        search_df = pd.DataFrame(list(search_result_from_db))
        # print(search_df)
        search_df.rename(inplace=True, columns={'paper__doi_url': 'url',
                                                'paper__title': 'title',
                                                'paper__journal': 'journal',
                                                'paper__abstract': 'abstract',
                                                'paper__authors': 'authors',
                                                'paper__year': 'year',
                                                'text': 'passage'})
        search_df['Score'] = search_df.apply(lambda row: passage_dist_lut[row['id']], axis=1)
        search_df_json = search_df.where(pd.notnull(search_df), '').to_dict('index')
        return JsonResponse(search_df_json)


class PlotOptionsPathwayExpressionView(ListAPIView):
    serializer_class = PlotOptionsPathwayExpressionSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PlotOptionsPathwayExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.MaterializedPathwayExpressionPlotPptions.objects.all()

        # Study ID
        study_id = self.request.query_params.get('study', 'GS-US-417-0301')
        study_id = study_id.split(',')

        queryset = queryset.filter(study_id__in=study_id)

        return queryset


class PlotOptionsPathwayOptionsView(ListAPIView):
    serializer_class = PlotOptionsPathwayOptionsSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(PlotOptionsPathwayOptionsView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Pathway.objects.all()

        queryset = queryset.values('pathway_set', 'pathway_name').distinct()

        return queryset


class CustomCategoricalView(ListAPIView):
    """
    This is an API endpoint to GET demographics data for the categorical variables in the custom view.

        Query Parameters:
            study: study IDs to filter by.
                This is a single value or a list of values separated by commas.
                default value: 'GLPG0634-CL-211'
    """
    serializer_class = CustomCategoricalSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(CustomCategoricalView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()

        # Join with the treatment arm table
        queryset = queryset.select_related('treatment_arm')

        # Join with the study table to get study name
        queryset = queryset.select_related('study')

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-211')
        study_id = study_id.split(',')
        queryset = queryset.filter(study_id__in=study_id)

        # Sex
        sex = self.request.query_params.get('sex', 'All')
        sex = sex.split(',')
        if 'All' not in sex:
            is_male = []
            for indiv_sex in sex:
                is_male.append(models.Subject.reverse_sex(indiv_sex))
            queryset = queryset.filter(is_male__in=is_male)

        # Race
        race = self.request.query_params.get('race', 'All')
        race = race.split(',')
        if 'All' not in race:
            queryset = queryset.filter(race__in=race)

        # Ethnicity
        ethnicity = self.request.query_params.get('ethnicity', 'All')
        ethnicity = ethnicity.split(',')
        if 'All' not in ethnicity:
            is_hispanic = []
            for indiv_ethnicity in ethnicity:
                is_hispanic.append(models.Subject.reverse_ethnicity(indiv_ethnicity))
            queryset = queryset.filter(is_hispanic__in=is_hispanic)

        # Age Binned
        age_binned = self.request.query_params.get('agebinned', 'All')
        age_binned = age_binned.split(',')
        if 'All' not in age_binned:
            acceptable_ages = []
            for indiv_age_range in age_binned:
                acceptable_ages.extend(models.Subject.reverse_age_binned(indiv_age_range))
            queryset = queryset.filter(age_years__in=acceptable_ages)

        return queryset

class CustomNumericalView(ListAPIView):
    """
    This is an API endpoint to **GET** biomarker and genomic data. This data is returned in a format most convenient for
        grouped box plots or violin plots.
    ## Query Parameters:
        biomarker: biomarker names.
            This can be a single value or a list of values separated by commas.
            default value: 'Serum Adiponectin'
        gene: gene id names.
            This can be a single value or a list of values separated by commas.
            default value: 'NOC2L'
        study: study number to select filter subjects by.
            This is a single value or a list of values separated by commas.
            default value: 'GLPG0634-CL-223' aka AS Phase 2 trial
        week: time points (in weeks) to filter test results by.
            This is a single value or a list of values separated by commas. Each value should be an integer.
            default value: 'All'
    ### Responder Status
        true: subject responded according to efficacy measure
        false: subject did not respond according to efficacy measure
        null: subject did not have an efficacy measure result at the specified time
    """

    serializer_class = CustomNumericalSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(CustomNumericalView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.Subject.objects.all()
        # Biomarker Name
        biomarker_name = str(self.request.query_params.get('biomarker', 'Serum Adiponectin'))
        biomarker_name = biomarker_name.split(',')
        biomarker_name = [x.replace('|||', ',') for x in biomarker_name]

        # Gene Id
        gene_id = str(self.request.query_params.get('gene', 'NOC2L'))
        gene_id = gene_id.split(',')

        # Study ID
        study_id = self.request.query_params.get('study', 'GLPG0634-CL-223')
        study_id = study_id.split(',')

        # Week Number
        query_week = self.request.query_params.get('week', 'All')

        treatments = models.Study.objects.select_related('study')
        tests = models.BiomarkerTest.objects.select_related('test')
        genes = models.GeneExpression.objects.select_related('subject')
        efficacy = models.EfficacyMeasures.objects.all()
        if query_week is not 'All':
            if isinstance(query_week, str):
                weeks = [int(x) for x in query_week.split(',')]
            else:
                weeks = [query_week]
            queryset = queryset.filter(biomarker_tests__test__name__in=biomarker_name,
                                       biomarker_tests__time_point__in=weeks,
                                       study_id__in=study_id).distinct()
            queryset = queryset.filter(gene_expressions__gene_id__in=gene_id,
                                       gene_expressions__time_point__in=weeks,
                                       study_id__in=study_id).distinct()
            queryset = queryset.prefetch_related(Prefetch('biomarker_tests',
                                                          queryset=tests.filter(
                                                              test__name__in=biomarker_name,
                                                              time_point__in=weeks), to_attr='biomarker_test_results'
                                                          )).select_related('treatment_arm')
            queryset = queryset.prefetch_related(Prefetch('gene_expressions',
                                                 queryset=genes.filter(
                                                     gene_id__in=gene_id,
                                                     time_point__in=weeks
                                                 ), to_attr='gene_test_results')).select_related('treatment_arm')

            queryset = queryset.select_related('study')
        else:
            queryset = queryset.filter(biomarker_tests__test__name__in=biomarker_name,
                                       study_id__in=study_id).distinct()
            queryset = queryset.filter(gene_expressions__gene_id__in=gene_id,
                                       study_id__in=study_id).distinct()
            queryset = queryset.prefetch_related(Prefetch('biomarker_tests',
                                                          queryset=tests.filter(
                                                              test__name__in=biomarker_name), to_attr='biomarker_test_results'
                                                          )).select_related('treatment_arm')
            queryset = queryset.prefetch_related(Prefetch('gene_expressions',
                                                          queryset=genes.filter(
                                                              gene_id__in=gene_id
                                                          ), to_attr='gene_test_results')).select_related('treatment_arm')

        return queryset.order_by('biomarker_tests__time_point')

class TcgaExpressionView(ListAPIView):
    """
    This is an API endpoint to **GET** TCGA gene expression data. This data is returned in a format most convenient for
        grouped box plots or violin plots.

    ## Query Parameters:
        gene: gene id names.
            This can be a single value or a list of values separated by commas.
            default value: 'NOC2L'

        tissue: Tissue sample types
            This can be a single value or a list of values separated by commas
            default value: 'All
    """
    serializer_class = TCGASerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(TcgaExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.TCGAExpression.objects.values('tpm', 'Tissue', 'project')
        # Gene Id
        gene_id = str(self.request.query_params.get('gene', 'NOC2L'))
        gene_id = gene_id.split(',')

        # Tissue Type
        tissue = self.request.query_params.get('tissue', 'All')
        tissue = tissue.split(',')

        if tissue[0] is not 'All':
            queryset = queryset.filter(gene_name__in=gene_id, project__in=tissue)
        else:
            queryset = queryset.filter(gene_name__in=gene_id)

        return queryset

class GtexExpressionView(ListAPIView):
    """
    This is an API endpoint to **GET** TCGA gene expression data. This data is returned in a format most convenient for
        grouped box plots or violin plots.

    ## Query Parameters:
        gene: gene id names.
            This can be a single value or a list of values separated by commas.
            default value: 'NOC2L'

        tissue: Tissue sample types
            This can be a single value or a list of values separated by commas
            default value: 'All
    """
    serializer_class = GTEXSerializer

    @method_decorator(cache_page(settings.API_CACHE_TTL))
    def dispatch(self, *args, **kwargs):
        return super(GtexExpressionView, self).dispatch(*args, **kwargs)

    def get_queryset(self):
        queryset = models.GTEXExpression.objects.values('tpm', 'sample_type')
        # Gene Id
        gene_id = str(self.request.query_params.get('gene', 'NOC2L'))
        gene_id = gene_id.split(',')

        # Tissue Type
        tissue = self.request.query_params.get('tissue', 'All')
        tissue = tissue.split(',')

        if tissue[0] is not 'All':
            queryset = queryset.filter(gene_name__in=gene_id, sample_type__in=tissue)
        else:
            queryset = queryset.filter(gene_name__in=gene_id)

        return queryset