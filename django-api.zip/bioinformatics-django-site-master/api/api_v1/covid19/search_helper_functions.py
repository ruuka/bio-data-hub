import spacy
import numpy as np
from spacy.lang.en import English
from gensim.models.word2vec import Word2Vec
from sklearn.feature_extraction.text import TfidfVectorizer

def prepare_spacy_model():
    nlp = English()
    nlp.tokenizer.add_special_case("urlLink", [{"ORTH": 'email-address'}])
    nlp.tokenizer.add_special_case("wuhan coronavirus", [{"ORTH": "covid-19"}])
    nlp.tokenizer.add_special_case("2019 novel coronavirus", [{"ORTH": "covid-19"}])
    nlp.tokenizer.add_special_case("sars-cov-2", [{"ORTH": "covid-19"}])
    nlp.tokenizer.add_special_case("2019-ncov", [{"ORTH": "covid-19"}])
    nlp.tokenizer.add_special_case("novel coronavirus pneumonia", [{"ORTH": "covid-19"}])
    nlp.tokenizer.add_special_case("wuhan pneumonia", [{"ORTH": "covid-19"}])
    nlp.tokenizer.add_special_case("%", [{"ORTH": "percent"}])

    return nlp


def process_data_with_spacy_model(text: str, nlp: spacy.lang.en.English, lemmatize: bool):
    doc = nlp(text)
    token_list = []
    for token in doc:
        if token.is_punct or token.is_space or token.is_stop:
            continue
        elif token.like_num:
            try:
                int_num = round(float(token.text))
            except:
                continue
            if -1 <= int_num <= 1:
                token_list.append('very-small-num')
            elif -50 <= int_num <= 50:
                token_list.append('small-num')
            elif -2000 <= int_num <= 1950:
                token_list.append('medium-num')
            elif 1950 < int_num <= 2021:
                token_list.append('year-num')
            elif -8000 <= int_num <= 8000:
                token_list.append('large-num')
            else:
                token_list.append('very-large-num')
        elif token.like_email:
            token_list.append('email-address')
        elif len(token) < 2:
            continue
        else:
            if token.text[-1] in ')]}':
                token_list.append(token.lower_[:-1])
            elif lemmatize:
                token_list.append(token.lemma_.lower())
            else:
                token_list.append(token.lower_)
    return token_list


def get_avg_vector(text, gensim_nlp, tfidf_model, lemmatize: bool=True):
    if isinstance(text, str):
        spacy_nlp = prepare_spacy_model()
        processed_list = process_data_with_spacy_model(text, spacy_nlp, lemmatize)
    elif isinstance(text, list):
        processed_list = text
    word_vector = None
    word_vector_count = 0
    tfidf_values = tfidf_model.transform([processed_list])
    for i, token in enumerate(processed_list):
        if token in gensim_nlp.vocab and token in tfidf_model.vocabulary_:
            tfidf_word_value = tfidf_values[0, tfidf_model.vocabulary_[token]]
            if word_vector is None:
                word_vector = gensim_nlp[token].copy()*tfidf_word_value
            else:
                word_vector += gensim_nlp[token]*tfidf_word_value
            word_vector_count += 1
        else:
            continue
    if word_vector_count > 0:
        word_vector = word_vector / word_vector_count
    else:
        word_vector = gensim_nlp['covid-19']
    word_vector = word_vector / tfidf_values.sum()
    return word_vector