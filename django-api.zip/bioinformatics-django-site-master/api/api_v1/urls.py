from django.urls import path, include
from .apiviews import GeneExpressionView, DifferentialGeneExpressionView, PathwayExpressionView, GeneView, PathwayView, \
    PossibleGeneNamesView, PlotOptionsGeneExpressionView, DemographicsView, PossibleBiomarkerNamesView, \
    PlotOptionsBiomarkerView, BiomarkerView, PlotOptionsDifferentialGeneExpressionView, StudyDataPlotOptionsView, \
    PublicationView, PossibleGeneAliasView, EfficacyMeasureOptionsView, BiomarkerCorrelation, \
    BiomarkerCorrelationScatterplotView, DeepSearchPapers, PlotOptionsPathwayExpressionView,\
    PlotOptionsPathwayOptionsView, CustomCategoricalView, CustomNumericalView, GeneExpressionMetadataView, BiomarkerMetadataView,\
    DemographicsTimeTreatmentView, DemographicsAndIDView, TcgaExpressionView, GtexExpressionView
from biomarker_cdm.api_v1.apiviews import UploadBiomarkersForStandardization, DownloadCompleteBiomarkerList, NCBILookup,\
    ListPreferredNames, ListSynonymNames, DatabaseLookup, IndividualStandardName, IndividualSynonym, \
    UploadUniprotCodesForStandardization, UniprotLookup, UpdateDatabaseView, GetStandardNames
from general_information.views import ContactFormSubmission

urlpatterns = [
    path('differential-gene-expression/', DifferentialGeneExpressionView.as_view(), name='differential_gene_expression'),
    path('plot-options/study-data/', StudyDataPlotOptionsView.as_view(), name='study_data_plot_options'),
    path('plot-options/differential-gene-expression/', PlotOptionsDifferentialGeneExpressionView.as_view(), name='differential_gene_expression_plot_options'),
    path('plot-options/gene-expression/', PlotOptionsGeneExpressionView.as_view(), name='gene_expression_plot_options'),
    path('plot-options/pathway-expression/', PlotOptionsPathwayExpressionView.as_view(), name='pathway_expression_plot_options'),
    path('plot-options/biomarkers/', PlotOptionsBiomarkerView.as_view(), name='biomarker_plot_options'),
    path('plot-options/all-pathways/', PlotOptionsPathwayOptionsView.as_view(), name='all_pathways'),
    path('plot-options/all-gene-ids/', PossibleGeneNamesView.as_view(), name='all_gene_ids'),
    path('plot-options/all-biomarker-names/', PossibleBiomarkerNamesView.as_view(), name='all_biomarker_names'),
    path('plot-options/all-gene-alias/', PossibleGeneAliasView.as_view(), name='all_gene_alias'),
    path('plot-options/efficacy/', EfficacyMeasureOptionsView.as_view(), name='efficacy_plot_options'),
    path('gene-expression/', GeneExpressionView.as_view(), name='gene_expression'),
    path('gene-expression-metadata/', GeneExpressionMetadataView.as_view(), name='gene_expression_metadata'),
    path('biomarkers/', BiomarkerView.as_view(), name='biomarkers'),
    path('biomarkers-metadata/', BiomarkerMetadataView.as_view(), name='biomarker_metadata'),
    path('pathway-expression/', PathwayExpressionView.as_view(), name='pathway_expression'),
    path('demographics/', DemographicsView.as_view(), name='demographics'),
    path('demographics-id/', DemographicsAndIDView.as_view(), name='demographics_id'),
    path('demographics-metadata/', DemographicsTimeTreatmentView.as_view(), name='demographics_timepoints'),
    path('gene/', GeneView.as_view(), name='gene'),
    path('pathway/', PathwayView.as_view(), name='pathway'),
    path('publications/', PublicationView, name='publications'),
    path('biomarker-correlation/', BiomarkerCorrelation.as_view(), name='biomarker_correlation'),
    path('biomarker-measure/', BiomarkerCorrelationScatterplotView.as_view(), name='biomarker_measure'),
    path('covid-19-papers/', DeepSearchPapers.as_view(), name='covid19_deep_search'),
    path('custom-plot/categorical-metadata', CustomCategoricalView.as_view(), name='custom_categorical'),
    path('custom-plot/categorical-anti-numerical', CustomNumericalView.as_view(), name='custom_anti_numerical'),
    path('public-data/tcga', TcgaExpressionView.as_view(), name='tcga_expression'),
    path('public-data/gtex', GtexExpressionView.as_view(), name='gtex_expression'),

    # Biomarker CDM
    path('biomarker-cdm/all-preferred-names/', ListPreferredNames.as_view(), name='all_preferred_names'),
    path('biomarker-cdm/select-synonym-names/', ListSynonymNames.as_view(), name='select_synonym_names'),
    path('biomarker-cdm/ncbi-lookup/', NCBILookup.as_view(), name='ncbi_lookup'),
    path('biomarker-cdm/uniprot-lookup/', UniprotLookup.as_view(), name='uniprot_lookup'),
    path('biomarker-cdm/database-lookup/', DatabaseLookup.as_view(), name='database_lookup'),
    path('biomarker-cdm/individual-standard-name/<int:pk>/', IndividualStandardName.as_view(), name='individual_standard_name'),
    path('biomarker-cdm/individual-synonym/<int:pk>/', IndividualSynonym.as_view(), name='individual_synonym'),
    path('biomarker-cdm/standardize-ncbi/', UploadBiomarkersForStandardization.as_view(), name='upload_biomarkers_ncbi'),
    path('biomarker-cdm/standardize-uniprot/', UploadUniprotCodesForStandardization.as_view(), name='upload_proteins_uniprot'),
    path('biomarker-cdm/download-all/', DownloadCompleteBiomarkerList.as_view(), name='download_excel_biomarkers'),
    path('biomarker-cdm/update-database/', UpdateDatabaseView.as_view(), name='update_database'),
    path('biomarker-cdm/get-standard-names/', GetStandardNames.as_view(), name='get_standard_names'),

    # General Information
    path('contact-us-email/', ContactFormSubmission.as_view(), name='contact_us_form_submission'),
]