from rest_framework import serializers
from api import models


class TCGASerializer(serializers.ModelSerializer):
    tpm = serializers.SerializerMethodField('get_tpm')

    def get_tpm(self, obj):
        return round(float(obj['tpm']), 2)

    class Meta:
        model = models.TCGAExpression
        fields = ('tpm', 'Tissue', 'project')

class GTEXSerializer(serializers.ModelSerializer):
    tpm = serializers.SerializerMethodField('get_tpm')

    def get_tpm(self, obj):
        return round(float(obj['tpm']), 2)

    class Meta:
        model = models.GTEXExpression
        fields = ('tpm', 'sample_type')
