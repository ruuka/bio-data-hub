from rest_framework import serializers
from api import models
from .base_serializers import StudySerializer


class IndividualDifferentialGeneExpressionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.DifferentialGeneExpression
        fields = ('gene_id', 'log_fc', 'fdr_p_value', 'p_value')


class DifferentialGeneExpressionSerializer(StudySerializer):
    differential_gene_expressions = IndividualDifferentialGeneExpressionSerializer(many=True, read_only=True)

    class Meta(StudySerializer.Meta):
        fields = StudySerializer.Meta.fields + ('differential_gene_expressions',)


class PlotOptionsDifferentialGeneExpressionSerializer(serializers.ModelSerializer):
    min_treatment = serializers.SerializerMethodField('get_min_treatment')
    sub_treatment = serializers.SerializerMethodField('get_sub_treatment')

    def get_min_treatment(self, obj):
        return obj.minuend_treatment_arm.preferred_name

    def get_sub_treatment(self, obj):
        if obj.subtrahend_treatment_arm:
            return obj.subtrahend_treatment_arm.preferred_name
        else:
            return None

    class Meta:
        model = models.DifferentialGeneExpression
        fields = ('study_id', 'tissue_source', 'first_time_point', 'first_time_point_string',
                  'second_time_point', 'second_time_point_string', 'min_treatment', 'sub_treatment')
