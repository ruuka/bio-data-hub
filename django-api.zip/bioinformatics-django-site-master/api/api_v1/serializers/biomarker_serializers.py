from rest_framework import serializers
from api import models
from .base_serializers import SubjectSerializer


class PossibleBiomarkerNamesSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.BiomarkerTestInfo
        fields = ('name', 'unit')


class PlotOptionsBiomarkerSerializer(serializers.ModelSerializer):
    study_id = serializers.SerializerMethodField('get_study_id')
    name = serializers.SerializerMethodField('get_name')
    unit = serializers.SerializerMethodField('get_unit')

    def get_study_id(self, obj):
        return obj.subject.study.study_id

    def get_name(self, obj):
        return obj.test.name

    def get_unit(self, obj):
        return obj.test.unit

    class Meta:
        model = models.BiomarkerTest
        fields = ('study_id', 'time_point', 'time_point_string', 'name', 'unit')


class IndividualBiomarkerSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField('get_name')
    value = serializers.SerializerMethodField('get_provided_value')
    day = serializers.SerializerMethodField('get_day')

    def get_name(self, obj):
        return obj.test.name

    def get_provided_value(self, obj):
        return obj.test_result

    def get_day(self, obj):
        return obj.day_number

    class Meta:
        model = models.BiomarkerTest
        fields = ('name', 'time_point', 'time_point_string', 'day', 'value')


class BiomarkerSerializer(SubjectSerializer):
    test_results = IndividualBiomarkerSerializer(many=True, read_only=True)
    indication = serializers.SerializerMethodField('get_indication')

    def get_indication(self, obj):
        return obj.study.indication

    class Meta(SubjectSerializer.Meta):
        fields = SubjectSerializer.Meta.fields + ('test_results', 'indication',)

class IndividualBiomarkerMetadataSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.BiomarkerTest
        fields = ('time_point', 'time_point_string')

class BiomarkerMetadataSerializer(IndividualBiomarkerMetadataSerializer):
    preferred_name = serializers.SerializerMethodField()
    time_point_string = serializers.SerializerMethodField()

    def get_time_point_string(self, obj):
        return models.get_time_point_string(obj['time_point'])

    def get_preferred_name(self, obj):
        return obj['subject__treatment_arm__preferred_name']

    class Meta(IndividualBiomarkerMetadataSerializer.Meta):
        fields = IndividualBiomarkerMetadataSerializer.Meta.fields + ('preferred_name', 'time_point_string')

class DemographicMetadataSerializer(IndividualBiomarkerMetadataSerializer):
    preferred_name = serializers.SerializerMethodField()
    id = serializers.SerializerMethodField()

    def get_id(self, obj):
        return obj['subject__id']

    def get_preferred_name(self, obj):
        return obj['subject__treatment_arm__preferred_name']

    class Meta(IndividualBiomarkerMetadataSerializer.Meta):
        fields = IndividualBiomarkerMetadataSerializer.Meta.fields + ('preferred_name', 'id',)


class BiomarkerCorrelationScatterplotSerializer(serializers.ModelSerializer):
    measure = serializers.SerializerMethodField()
    biomarker = serializers.SerializerMethodField()
    unit = serializers.SerializerMethodField()

    def get_unit(self, obj):
        return obj['test__unit']

    def get_measure(self, obj):
        if isinstance(obj['measure'], dict):
            measure = obj['measure']['value']
        else:
            measure = obj['measure']
        if measure is True:
            return 1
        elif measure is False:
            return 0
        else:
            return measure

    def get_biomarker(self, obj):
        return obj['test_result']

    class Meta:
        model = models.BiomarkerTest
        fields = ('measure', 'biomarker', 'unit')
