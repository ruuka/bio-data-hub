from rest_framework import serializers
from api import models
from random import randint
from uuid import UUID

class DemographicsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Subject
        fields = ('sex', 'race', 'ethnicity', 'age_binned', 'bmi_binned')

class DemographicsAndIDSerializer(serializers.ModelSerializer):
    age = serializers.SerializerMethodField('get_age')
    bmi = serializers.SerializerMethodField('get_bmi')
    race = serializers.SerializerMethodField('get_race')

    def get_age(self, obj):
        return obj.age_binned

    def get_bmi(self, obj):
        return obj.bmi_binned

    def get_race(self, obj):
        return obj.race if obj.race != None else 'Unknown'

    class Meta:
        model = models.Subject
        fields = ('id', 'sex', 'race', 'ethnicity', 'age', 'bmi')

class SubjectSerializer(DemographicsSerializer):
    treatment = serializers.SerializerMethodField('get_treatment')
    responder = serializers.SerializerMethodField('get_responder')
    uuid = serializers.SerializerMethodField('get_uuid')

    seed = randint(0,1000000000)

    def get_uuid(self, obj):
        return UUID(int= SubjectSerializer.seed +obj.id)

    def get_treatment(self, obj):
        return obj.treatment_arm.preferred_name

    def get_responder(self, obj):
        try:
            if obj.efficacy_measures.all()[0].result['value'] == True:
                return 'Responder'
            elif obj.efficacy_measures.all()[0].result['value'] == False:
                return 'Non-Responder'
            else:
                return 'Unknown'
        except:
            return 'Unknown'

    class Meta(DemographicsSerializer.Meta):
        depth = 1
        fields = DemographicsSerializer.Meta.fields + ('uuid', 'treatment', 'study_id', 'responder')


class GeneSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Gene
        fields = ('gene_symbol', 'description')


class PathwaySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Pathway
        fields = ('pathway_set', 'pathway_name', 'description')


class StudySerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Study
        depth = 1
        fields = ('study_id', 'indication')


class StudyDataOptionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.MaterializedStudyDataOptions
        fields = ('therapeutic_area', 'indication', 'study_id', 'study_name', 'num_subj_with_gene_exp', 'num_subj_with_pathway_exp',
                  'num_subj_with_biomarkers', 'study_has_diff_exp', 'study_has_pathway_diff_exp', 'num_subj_total')


class EfficacyMeasureOptionsSerializer(serializers.ModelSerializer):
    text = serializers.SerializerMethodField('get_text')

    def get_text(self, obj):
        return obj.measure_name + ' at ' + obj.time_point_string

    class Meta:
        model = models.EfficacyMeasures
        fields = ('measure_name', 'time_point', 'time_point_string', 'text')
