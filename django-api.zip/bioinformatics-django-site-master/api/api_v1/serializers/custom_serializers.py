from rest_framework import serializers
from .base_serializers import DemographicsSerializer, SubjectSerializer
from api import models
from .gene_expression_serializers import IndividualGeneExpressionSerializer
from .biomarker_serializers import IndividualBiomarkerSerializer

class CustomCategoricalSerializer(serializers.ModelSerializer):


    class Meta:
        model = models.Subject
        fields = ('sex', 'race', 'ethnicity', 'age_binned', 'bmi_binned')

class CustomNumericalSerializer(SubjectSerializer):
    gene_test_results = IndividualGeneExpressionSerializer(many=True, read_only=True)
    biomarker_test_results = IndividualBiomarkerSerializer(many=True, read_only=True)
    indication = serializers.SerializerMethodField('get_indication')

    def get_indication(self, obj):
        return obj.study.indication

    class Meta(SubjectSerializer.Meta):
        fields = ('treatment', 'indication', 'gene_test_results', 'biomarker_test_results',)