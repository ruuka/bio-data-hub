from rest_framework import serializers
from api import models
from .base_serializers import SubjectSerializer


class IndividualGeneExpressionSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField('get_name')
    value = serializers.SerializerMethodField('get_provided_value')

    def get_name(self, obj):
        return obj.gene_id

    def get_provided_value(self, obj):
        return obj.log_2_tpm

    class Meta:
        model = models.GeneExpression
        fields = ('name', 'time_point', 'time_point_string', 'tissue_source', 'value')


class GeneExpressionSerializer(SubjectSerializer):
    test_results = IndividualGeneExpressionSerializer(many=True, read_only=True)
    indication = serializers.SerializerMethodField('get_indication')

    def get_indication(self, obj):
        return obj.study.indication

    class Meta(SubjectSerializer.Meta):
        fields = SubjectSerializer.Meta.fields + ('test_results', 'indication',)

class IndividualGeneMetadataSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.MaterializedGeneMetadataSummaryOptions
        fields = ('tissue_source', 'time_point', 'time_point_string')

class GeneMetadataSerializer(IndividualGeneMetadataSerializer):
    treatment = serializers.SerializerMethodField()

    def get_treatment(self, obj):
        return obj.preferred_name

    class Meta(IndividualGeneMetadataSerializer.Meta):
        fields = IndividualGeneMetadataSerializer.Meta.fields + ('treatment',)

class PossibleGeneNamesSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Gene
        fields = ('gene_symbol',)

class PossibleGeneAliasSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.GeneAlias
        fields = ('gene_id', 'alias_symbols', 'gene_value')


class PlotOptionsGeneExpressionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.MaterializedGeneExpressionPlotOptions
        fields = ('indication', 'study_id', 'tissue_source', 'time_point', 'time_point_string')
