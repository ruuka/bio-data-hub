from rest_framework import serializers
from api import models
from .base_serializers import SubjectSerializer


class IndividualPathwayExpressionSerializer(serializers.ModelSerializer):
    pathway_name = serializers.SerializerMethodField('get_pathway_name')
    pathway_set = serializers.SerializerMethodField('get_pathway_set')
    value = serializers.SerializerMethodField('get_provided_value')

    def get_pathway_name(self, obj):
        return obj.pathway.pathway_name

    def get_pathway_set(self, obj):
        return obj.pathway.pathway_set

    def get_provided_value(self, obj):
        return obj.ssgsea

    class Meta:
        model = models.PathwayExpression
        fields = ('pathway_set', 'pathway_name', 'time_point', 'time_point_string', 'value')


class PathwayExpressionSerializer(SubjectSerializer):
    test_results = IndividualPathwayExpressionSerializer(many=True, read_only=True)

    class Meta(SubjectSerializer.Meta):
        fields = SubjectSerializer.Meta.fields + ('test_results',)


class PlotOptionsPathwayExpressionSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.MaterializedPathwayExpressionPlotPptions
        fields = ('study_id', 'time_point', 'time_point_string', 'tissue_source', 'pathway_set')


class PlotOptionsPathwayOptionsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.Pathway
        fields = ('pathway_set', 'pathway_name')
