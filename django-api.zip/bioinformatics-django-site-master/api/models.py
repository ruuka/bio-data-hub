# -*- coding: utf-8 -*-

from django.db import models
from django.db.models import JSONField
from django.contrib.postgres.fields import ArrayField
from django.contrib.postgres.indexes import GinIndex

# TODO Add db_table attributes to change table names


def extract_time(current_time_remaining, minutes_per_unit):
    num_of_unit = current_time_remaining // minutes_per_unit
    remainder_time = current_time_remaining % minutes_per_unit
    return num_of_unit, remainder_time


def get_time_point_string(time_point_in_minutes: int):
    if time_point_in_minutes == 0:
        return 'Baseline'

    weeks, remaining_time = extract_time(time_point_in_minutes, 10080)
    days, remaining_time = extract_time(remaining_time, 1440)
    hours, minutes = extract_time(remaining_time, 60)


    if weeks:
        if weeks == 1:
            weeks_string = '1 Week'
        else:
            weeks_string = '{0} Weeks'.format(weeks)
    else:
        weeks_string = ''

    if days:
        if days == 1:
            days_string = '1 Day'
        else:
            days_string = '{0} Days'.format(days)
    else:
        days_string = ''

    if hours:
        if hours == 1:
            hours_string = '1 Hour'
        else:
            hours_string = '{0} Hours'.format(hours)
    else:
        hours_string = ''

    if minutes:
        if minutes == 1:
            minutes_string = '1 Minute'
        else:
            minutes_string = '{0} Minutes'.format(minutes)
    else:
        minutes_string = ''

    time_string = ' '.join([x for x in [weeks_string, days_string, hours_string, minutes_string] if len(x) > 0])
    return time_string




class customRealField(models.FloatField):
    def db_type(self, connection):
        return 'real'


class TissueChoices(models.TextChoices):
    WHOLE_BLOOD = 'Whole Blood'
    LIVER = 'Liver'
    GASTRIC = 'Gastric Tissue'
    LIVER_LYMPH = 'Liver or Lymph Node'
    COLON = 'Colon'
    DUODENUM = 'Duodenum'
    ESOPHAGUS = 'Esophagus'
    GI_FIBROADIPOSE = 'GI Fibroadipose Tissue'
    GI_FIBROUS = 'GI Fibrous Tissue'
    GASTRODUODENAL_JCT = 'Gastroduodenal Junction'
    GASTROESOPHAGEAL_JCT = 'Gastroesophageal Junction'
    LYMPH = 'Lymph Node'
    GI_SMOOTH_MUSCLE = 'GI Smooth Muscle'
    SQUAMOUS_MUCOSA = 'Squamous Mucosa'
    STOMACH = 'Stomach'
    MUCOSAL = 'Mucosal Biopsy'


class BiomarkerSpecimentTypeChoices(models.TextChoices):
    serum = 'Serum'
    plasma = 'Plasma'
    urine = 'Urine'
    WHOLE_BLOOD = 'Whole Blood'


class UnitChoices(models.TextChoices):
    #ug_ml = (u'\u03BC' + 'g/mL').encode('utf-8').decode('utf-8')
    ng_ml = 'ng/mL'
    mg_g = 'mg/g'
    pg_ml = 'pg/mL'
    mg_l = 'mg/L'
    u_l = 'U/L'
    miu_ml = 'mIU/mL'
    kiu_ml = 'kIU/mL'
    percent = '%'


class StudyChoices(models.TextChoices):
    FITZROY = 'GLPG0634-CL-211'
    FINCH1 = 'GS-US-417-0301'
    FINCH2 = 'GS-US-417-0302'
    FINCH3 = 'GS-US-417-0303'
    SIM105 = 'GS-US-321-0105'
    SIM106 = 'GS-US-321-0106'
    SEL1943 = 'GS-US-384-1943'
    SEL1944 = 'GS-US-384-1944'
    AS223 = 'GLPG0634-CL-223'
    ATLAS = 'GS-US-454-4378'
    CLE4092 = 'GS-US-436-4092'
    SJS4189 = 'GS-US-445-4189'
    GC2013 = 'GS-US-296-2013'
    DKDPH2 = 'GS-US-223-1015'
    HBV2021 = 'GS-US-389-2021'
    HBV2022 = 'GS-US-389-2022'
    HBV2024 = 'GS-US-389-2024'
    HBV2025 = 'GS-US-389-2025'
    SELCOA = 'GS-US-418-3898 (Cohort A)'
    SELCOB = 'GS-US-418-3898 (Cohort B)'


class IndicationChoices(models.TextChoices):
    CROHNS = 'Crohn\'s Disease'
    AS = 'Ankylosing Spondylitis'
    RA = 'Rheumatoid Arthritis'
    NASH = 'Nonalcoholic Steatohepatitis'
    CLE = 'Cutaneous Lupus Erythematosus'
    SJSWRONG = 'Stevens-Johnson Syndrome'
    SJS = 'Sjogren\'s Syndrome'
    GC = 'Gastric Adenocarcinoma'
    DKD = 'Diabetic Kidney Disease'
    HBV = 'Hepatitis B Infection'
    UC = 'Ulcerative Colitis'



class TherapeuticAreaChoices(models.TextChoices):
    INFLAMMATION = 'Inflammation'
    VIROLOGY = 'Virology'
    ONCOLOGY = 'Oncology'


class DoseUnitChoices(models.TextChoices):
    MG = 'mg'
    MGPERKG = 'mg/kg'


class RaceChoices(models.TextChoices):
    WHITE = 'White'
    BLACK = 'Black or African American'
    AMERICAN_INDIAN = 'American Indian or Alaska Native'
    ASIAN = 'Asian'
    PACIFIC_ISLANDER = 'Native Hawaiian or Other Pacific Islander'
    OTHER = 'Other'
    UNKNOWN = None


class TreatmentChoices(models.TextChoices):
    FILGOTINIB = 'Filgotinib'
    PLACEBO = 'Placebo'
    SELONSERTIB = 'Selonsertib'
    METHOTREXATE = 'Methotrexate'
    ADALIMUMAB = 'Adalimumab'
    SIMTUZUMAB = 'Simtuzumab'
    FIRSOCOSTAT = 'Firsocostat'
    CILOFEXOR = 'Cilofexor'
    LANRAPLENIB = 'Lanraplenib'
    TIRABRUTINIB = 'Tirabrutinib'
    ANDECALIXIMAB = 'Andecaliximab'
    NIVOLUMAB = 'Nivolumab'
    SELGANTOLIMOD = 'Selgantolimod'


class PathwaySetChoices(models.TextChoices):
    HALLMARK = 'HALLMARK'
    BIOCARTA = 'BIOCARTA'
    CP_OTHER = 'CP_OTHER'
    GO = 'GO'
    KEGG = 'KEGG'
    NABA = 'NABA'
    PID = 'PID'
    REACTOME = 'REACTOME'
    SA = 'SA'
    SIG = 'SIG'
    WNT = 'WNT'
    LIT = 'LIT'


class EfficacyMeasureChoices(models.TextChoices):
    DASCRPRM = 'DASCRPRM'
    DASCRPLO = 'DASCRPLO'
    DAS28CRP = 'DAS28CRP'
    CDAILO = 'CDAILO'
    CDAI = 'CDAI'
    ACRN = 'ACRN'
    ACR70 = 'ACR70'
    ACR50 = 'ACR50'
    ACR20 = 'ACR20'
    SESCDBL = 'SESCDBL'
    ENDORSP = 'ENDORSP'
    CRSBLFL = 'CRSBLFL'
    ATNFGR3 = 'is_antiTNFexpr'
    ELFRESP = 'ELF Responder'
    CRNRESP = 'NASH CRN Fibrosis Responder'
    BOR = 'BOR'
    SLOPE_4_48 = 'Slope from Wks 4 to 48'
    EBSREM = 'EBSREM'
    MCSREM = 'MCSREM'
    GEBOREM = 'GEBOREM'

# Create your models here.
class Study(models.Model):
    study_id = models.TextField(db_column='study_id', blank=False, null=False, primary_key=True, choices=StudyChoices.choices)
    indication = models.TextField(db_column='indication', blank=False, null=False, choices=IndicationChoices.choices)
    therapeutic_area = models.TextField('therapeutic_area', blank=False, null=False, choices=TherapeuticAreaChoices.choices)
    name = models.TextField(db_column='name', blank=True, null=False)

    class Meta:
        db_table = 'study'
        indexes = [
            models.Index(fields=['indication']),
            models.Index(fields=['therapeutic_area']),
            models.Index(fields=['therapeutic_area', 'indication']),
        ]
        constraints = [
            models.CheckConstraint(check=models.Q(study_id__in=StudyChoices.values), name='constrained study ids'),
            models.CheckConstraint(check=models.Q(indication__in=IndicationChoices.values), name='constrained indications'),
            models.CheckConstraint(check=models.Q(therapeutic_area__in=TherapeuticAreaChoices.values), name='constrained therapeutic areas'),
        ]


class Subject(models.Model):
    unique_subject_id = models.TextField(db_column='unique_subject_id', blank=False, null=False)
    is_healthy = models.BooleanField(db_column='is_healthy', null=False, blank=False, default=False)
    is_male = models.BooleanField(db_column='is_male', null=True, blank=False)
    race = models.TextField(db_column='race', blank=False, null=True, choices=RaceChoices.choices)
    is_hispanic = models.BooleanField(db_column='is_hispanic', null=True, blank=False)
    treatment_arm = models.ForeignKey(to='TreatmentArm', on_delete=models.PROTECT, blank=True, null=True,
                                      related_name='subjects')
    age_years = models.PositiveIntegerField(db_column='age_years', null=True, blank=False)
    bmi = customRealField(db_column='bmi', null=True, blank=False)
    study = models.ForeignKey(to='Study', on_delete=models.PROTECT, null=False, blank=False,
                              related_name='subjects')

    @property
    def ethnicity(self):
        return self.get_ethnicity(self.is_hispanic)

    @staticmethod
    def get_ethnicity(is_hispanic):
        if is_hispanic is None:
            return 'NA'
        elif is_hispanic:
            return 'Hispanic or Latino'
        else:
            return 'Not Hispanic or Latino'

    @staticmethod
    def reverse_ethnicity(ethnicity):
        if ethnicity == 'NA':
            return None
        elif ethnicity == 'Hispanic or Latino':
            return True
        elif ethnicity == 'Not Hispanic or Latino':
            return False
        else:
            raise ValueError('Incorrect value for "ethnicity"')

    @property
    def sex(self):
        return self.get_sex(self.is_male)

    @staticmethod
    def get_sex(is_male):
        if is_male is None:
            return 'NA'
        elif is_male:
            return 'Male'
        else:
            return 'Female'

    @staticmethod
    def reverse_sex(sex):
        if sex == 'NA':
            return None
        elif sex == 'Male':
            return True
        elif sex == 'Female':
            return False
        else:
            raise ValueError('Incorrect value for "sex"')

    @staticmethod
    def get_age_binned(age_years):
        if age_years is None:
            return 'unknown age'
        elif age_years <= 18:
            return '0 - 18 years old'
        elif age_years <= 35:
            return '19 - 35 years old'
        elif age_years <= 55:
            return '36 - 55 years old'
        elif age_years <= 150:
            return '56+ years old'
        else:
            return 'unknown age'

    @property
    def age_binned(self):
        return self.get_age_binned(self.age_years)

    @staticmethod
    def reverse_age_binned(age_binned):
        if age_binned == 'unknown age':
            return [None]
        elif age_binned == '0 - 18 years old':
            return list(range(0, 19))
        elif age_binned == '19 - 35 years old':
            return list(range(19, 36))
        elif age_binned == '36 - 55 years old':
            return list(range(36, 56))
        elif age_binned == '56  years old':
            return list(range(56, 120))
        else:
            raise ValueError('Incorrect value for "age_binned"')

    @staticmethod
    def get_bmi_binned(bmi):
        """This definition comes from the CDC: https://www.cdc.gov/obesity/adult/defining.html"""
        if bmi is None:
            return 'unknown weight'
        elif bmi < 18.5:
            return 'underweight'
        elif bmi < 25:
            return 'normal weight'
        elif bmi < 30:
            return 'overweight'
        elif bmi < 200:
            return 'obese'
        else:
            return 'unknown weight'

    @property
    def bmi_binned(self):
        return self.get_bmi_binned(self.bmi)

    class Meta:
        db_table = 'subject'
        constraints = [
            models.UniqueConstraint(fields=['unique_subject_id'], name='subject_id_is_unique'),
            models.CheckConstraint(check=models.Q(age_years__lte=130), name='age_years_lte_130'),
            #models.CheckConstraint(check=models.Q(bmi__gte=7), name='bmi_gte_7'),
            #models.CheckConstraint(check=models.Q(bmi__lte=250), name='bmi_lte_250'),
            models.CheckConstraint(check=models.Q(race__in=RaceChoices.values), name='constrained race choices'),
        ]
        indexes = [
            models.Index(fields=['study']),
            models.Index(fields=['is_male']),
            models.Index(fields=['age_years']),
            models.Index(fields=['bmi']),
            models.Index(fields=['race', 'is_hispanic']),
            models.Index(fields=['treatment_arm']),
        ]


class BiomarkerTestInfo(models.Model):
    name = models.TextField(db_column='name', blank=False, null=False)
    unit = models.TextField(db_column='unit', blank=False, null=True)

    class Meta:
        db_table = 'biomarker_test_info'
        constraints = [
            models.UniqueConstraint(fields=['name'], name='unique biomarker test name and specimen'),
        ]
        indexes = [
            models.Index(fields=['name']),
        ]


class BiomarkerTest(models.Model):
    time_point = models.PositiveIntegerField(db_column='time_point', blank=False, null=False)  # this is in number of weeks
    day_number = models.IntegerField(db_column='day_time_point', blank=False, null=True)
    test_result = customRealField(db_column='test_result', blank=False, null=False)
    subject = models.ForeignKey(to='Subject', on_delete=models.CASCADE, blank=False, null=False,
                                related_name='biomarker_tests')
    lloq = models.BooleanField(db_column='lloq', blank=False, null=False, default=False)
    uloq = models.BooleanField(db_column='uloq', blank=False, null=False, default=False)
    test = models.ForeignKey(to='BiomarkerTestInfo', on_delete=models.PROTECT, blank=False, null=False,
                             related_name='biomarker_test_instances')

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def time_point_string(self):
        return get_time_point_string(self.time_point)

    class Meta:
        db_table = 'biomarker_tests'
        constraints = [
            models.UniqueConstraint(fields=['test', 'time_point', 'subject'], name='unique biomarker test per binned week'),
        ]
        indexes = [
            models.Index(fields=['test', 'time_point', 'subject']),
            models.Index(fields=['subject'])
        ]


class TreatmentComponent(models.Model):
    active_name = models.TextField(db_column='active_name', blank=False, null=True, choices=TreatmentChoices.choices)
    treatment_arm = models.ForeignKey(to='TreatmentArm', on_delete=models.PROTECT, blank=False, null=False,
                                      related_name='treatment_arms')
    description = models.TextField(db_column='description', blank=True, null=True)
    dose = customRealField(db_column='dose', blank=False, null=True)
    unit = models.TextField(db_column='unit', blank=False, null=False)

    class Meta:
        db_table = 'treatment_component'
        constraints = [
            models.UniqueConstraint(fields=['active_name', 'treatment_arm'], name='unique active per arm'),
            models.CheckConstraint(check=models.Q(active_name__in=TreatmentChoices.values), name='constrained treatment choices'),
            models.CheckConstraint(check=models.Q(dose_mg__gte=0), name='dose is positive'),
            models.CheckConstraint(check=models.Q(unit__in=DoseUnitChoices.values), name='constrained unit choices')
        ]


class TreatmentArm(models.Model):
    preferred_name = models.TextField(db_column='preferred_name', blank=False, null=False)

    class Meta:
        db_table = 'treatment_arm'
        constraints = [
            models.UniqueConstraint(fields=['preferred_name'], name='unique treatment arm name')
        ]


class Gene(models.Model):
    gene_symbol = models.TextField(db_column='gene_symbol', blank=False, null=False, primary_key=True)
    description = models.TextField(db_column='description', blank=True, null=True)

    class Meta:
        db_table = 'gene_info'


class GeneAlias(models.Model):
    gene = models.ForeignKey(to='Gene', on_delete=models.PROTECT, blank=False, null=False,
                             related_name='gene_aliases')
    alias_symbols = models.TextField(db_column='alias_symbol', blank=True, null=True)
    gene_value = models.TextField(db_column='gene_value', blank=False, null=False)

    class Meta:
        db_table = 'gene_alias'


class Pathway(models.Model):
    pathway_set = models.TextField(db_column='pathway_set', blank=False, null=False, choices=PathwaySetChoices.choices)
    pathway_name = models.TextField(db_column='pathway_name', blank=False, null=False)
    description = models.TextField(db_column='description', blank=True, null=True)

    class Meta:
        db_table = 'pathway_info'
        constraints = [
            models.UniqueConstraint(fields=['pathway_set', 'pathway_name'], name='unique_pathway'),
            models.CheckConstraint(check=models.Q(pathway_set__in=PathwaySetChoices.values), name='constrained pathway set names')
        ]
        indexes = [
            models.Index(fields=['pathway_set', 'pathway_name'])
        ]


class Expression(models.Model):
    tissue_source = models.TextField(db_column='tissue_source', blank=False, null=False, choices=TissueChoices.choices)

    class Meta:
        constraints = [
            models.CheckConstraint(check=models.Q(tissue_source__in=TissueChoices.values), name='%(class)s_constrained tissue choices')
        ]
        abstract = True


class RegularExpression(Expression):
    time_point = models.PositiveIntegerField(db_column='time_point', blank=False, null=False)  # this is in number of weeks

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def time_point_string(self):
        return get_time_point_string(self.time_point)

    class Meta(Expression.Meta):
        abstract = True


class GeneExpression(RegularExpression):
    log_2_tpm = customRealField(db_column='log_2_tpm', blank=False, null=False)
    gene = models.ForeignKey(to='Gene', on_delete=models.PROTECT, blank=False, null=False,
                             related_name='gene_expressions')
    subject = models.ForeignKey(to='Subject', on_delete=models.CASCADE, blank=False, null=False,
                                related_name='gene_expressions')

    class Meta(RegularExpression.Meta):
        db_table = 'gene_expression'
        constraints = RegularExpression.Meta.constraints + [
            models.UniqueConstraint(fields=['tissue_source', 'time_point', 'gene', 'subject'], name='unique_gene_expression')
        ]
        indexes = [
            models.Index(fields=['subject', 'tissue_source', 'time_point']),
            models.Index(fields=['tissue_source', 'gene', 'time_point', 'subject']),
            models.Index(fields=['subject']),
        ]

class PathwayExpression(RegularExpression):
    ssgsea = customRealField(db_column='ssgsea', blank=False, null=False)
    pathway = models.ForeignKey(to='Pathway', on_delete=models.PROTECT, blank=False, null=False,
                                related_name='pathway_expressions')
    subject = models.ForeignKey(to='Subject', on_delete=models.CASCADE, blank=False, null=False,
                                related_name='pathway_expressions')

    class Meta(RegularExpression.Meta):
        db_table = 'pathway_expression'
        constraints = RegularExpression.Meta.constraints + [
            models.UniqueConstraint(fields=['tissue_source', 'time_point', 'pathway', 'subject'], name='unique_pathway_expression')
        ]
        indexes = [
            models.Index(fields=['tissue_source', 'pathway', 'time_point', 'subject']),
            models.Index(fields=['subject', 'pathway', 'tissue_source', 'time_point']),
            models.Index(fields=['subject']),
        ]


class DifferentialExpression(Expression):
    first_time_point = models.PositiveIntegerField(db_column='first_time_point', null=False, blank=False)
    second_time_point = models.PositiveIntegerField(db_column='second_time_point', null=False, blank=False)
    log_fc = customRealField(db_column='log_fc', blank=False, null=False)
    log_fc_upper_ci = customRealField(db_column='log_fc_upper_ci', blank=False, null=True)
    log_fc_lower_ci = customRealField(db_column='log_fc_lower_ci', blank=False, null=True)
    p_value = customRealField(db_column='p_value', blank=True, null=True)
    fdr_p_value = customRealField(db_column='fdr_p_value', blank=True, null=True)

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def first_time_point_string(self):
        return get_time_point_string(self.first_time_point)

    @property
    def second_time_point_string(self):
        return get_time_point_string(self.second_time_point)

    class Meta(Expression.Meta):
        abstract = True
        indexes = [
            models.Index(fields=['log_fc']),
            models.Index(fields=['p_value']),
            models.Index(fields=['fdr_p_value']),
        ]
        constraints = Expression.Meta.constraints


class DifferentialGeneExpression(DifferentialExpression):
    minuend_treatment_arm = models.ForeignKey(to='TreatmentArm', blank=False, on_delete=models.PROTECT, null=False,
                                              related_name='minuend_differential_gene_expressions')
    subtrahend_treatment_arm = models.ForeignKey(to='TreatmentArm', blank=True, on_delete=models.PROTECT, null=True,
                                                 related_name='subtrahend_differential_gene_expressions')
    study = models.ForeignKey(to='Study', on_delete=models.PROTECT, blank=False, null=False,
                              related_name='differential_gene_expressions')
    gene = models.ForeignKey(to='Gene', on_delete=models.PROTECT, blank=False, null=False,
                             related_name='differential_gene_expressions')

    class Meta(DifferentialExpression.Meta):
        db_table = 'differential_gene_expression'
        constraints = DifferentialExpression.Meta.constraints + [
            models.UniqueConstraint(fields=['study', 'tissue_source', 'gene', 'first_time_point', 'second_time_point',
                                            'minuend_treatment_arm', 'subtrahend_treatment_arm'],
                                    name='unique_differential_gene_expression')
        ]
        indexes = DifferentialExpression.Meta.indexes + [
            models.Index(fields=['study', 'tissue_source', 'first_time_point', 'second_time_point',
                                 'minuend_treatment_arm', 'subtrahend_treatment_arm', 'gene']),
            models.Index(fields=['gene']),
            models.Index(fields=['study']),
        ]


class DifferentialPathwayExpression(DifferentialExpression):
    minuend_treatment_arm = models.ForeignKey(to='TreatmentArm', blank=False, on_delete=models.PROTECT, null=False,
                                              related_name='minuend_differential_pathway_expressions')
    subtrahend_treatment_arm = models.ForeignKey(to='TreatmentArm', blank=True, on_delete=models.PROTECT, null=True,
                                                 related_name='subtrahend_differential_pathway_expressions')
    study = models.ForeignKey(to='Study', on_delete=models.PROTECT, blank=False, null=False,
                              related_name='differential_pathway_expressions')
    pathway = models.ForeignKey(to='Pathway', on_delete=models.PROTECT, blank=False, null=False,
                                related_name='differential_pathway_expressions')

    class Meta(DifferentialExpression.Meta):
        db_table = 'differential_pathway_expression'
        constraints = DifferentialExpression.Meta.constraints + [
            models.UniqueConstraint(fields=['study', 'tissue_source', 'pathway', 'first_time_point',
                                            'second_time_point',  'minuend_treatment_arm', 'subtrahend_treatment_arm'],
                                    name='unique_differential_pathway_expression')
        ]
        indexes = DifferentialExpression.Meta.indexes + [
            models.Index(fields=['study', 'tissue_source', 'first_time_point', 'second_time_point',
                                 'minuend_treatment_arm', 'subtrahend_treatment_arm', 'pathway']),
            models.Index(fields=['pathway']),
            models.Index(fields=['study']),
        ]


class MaterializedGeneExpressionPlotOptions(models.Model):
    therapeutic_area = models.TextField(db_column='therapeutic_area')
    indication = models.TextField(db_column='indication')
    study_id = models.TextField(db_column='study_id')
    tissue_source = models.TextField(db_column='tissue_source')
    time_point = models.PositiveIntegerField(db_column='time_point')  # this is in number of weeks

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def time_point_string(self):
        return get_time_point_string(self.time_point)

    class Meta:
        db_table = 'materialized_gene_expression_plot_options'
        managed = False


class MaterializedStudyDataOptions(models.Model):
    therapeutic_area = models.TextField(db_column='therapeutic_area')
    indication = models.TextField(db_column='indication')
    study_id = models.TextField(db_column='study_id')
    study_name = models.TextField(db_column='study_name')
    num_subj_total = models.PositiveIntegerField(db_column='num_subj_total')
    num_subj_with_gene_exp = models.PositiveIntegerField(db_column='num_subj_with_gene_exp')
    num_subj_with_pathway_exp = models.PositiveIntegerField(db_column='num_subj_with_pathway_exp')
    num_subj_with_biomarkers = models.PositiveIntegerField(db_column='num_subj_with_biomarkers')
    study_has_diff_exp = models.BooleanField(db_column='study_has_diff_exp')
    study_has_pathway_diff_exp = models.BooleanField(db_column='study_has_pathway_diff_exp')

    class Meta:
        db_table = 'materialized_study_data_options'
        managed = False

class MaterializedGeneMetadataSummaryOptions(models.Model):
    study_id = models.TextField(db_column='study_id')
    tissue_source = models.TextField(db_column='tissue_source')
    time_point = models.PositiveIntegerField(db_column='time_point', blank=False, null=False)
    preferred_name = models.TextField(db_column='preferred_name', blank=False, null=False)

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def time_point_string(self):
        return get_time_point_string(self.time_point)

    class Meta:
        db_table = 'gene_metadatasummary'
        managed = False


class EfficacyMeasures(models.Model):
    subject = models.ForeignKey(to='Subject', on_delete=models.CASCADE, blank=False, null=False,
                                related_name='efficacy_measures')
    measure_name = models.TextField(db_column='measure_name', blank=False, null=False)
    time_point = models.PositiveIntegerField(db_column='time_point', blank=False, null=False)
    result = JSONField()
    """
    FORMAT OF RESULT:
        value:
        type: 'bool' or 'numeric'
    """

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def time_point_string(self):
        return get_time_point_string(self.time_point)

    class Meta:
        db_table = 'efficacy_measures'
        constraints = [
            models.UniqueConstraint(fields=['subject', 'measure_name', 'time_point'], name='unique efficacy measure'),
            models.CheckConstraint(check=models.Q(measure_name__in=EfficacyMeasureChoices.values), name='constrained efficacy measures')
        ]
        indexes = [
            models.Index(fields=['subject']),
            models.Index(fields=['measure_name', 'time_point', 'subject']),
            GinIndex(fields=['result'], name='efficacy_result_gin_idx')
        ]


# Create your models here.
class COVID19Paper(models.Model):
    id = models.TextField(primary_key=True)
    doi_url = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    abstract = models.TextField(blank=True, null=True)
    journal = models.TextField(blank=True, null=True)
    authors = models.TextField(blank=True, null=True)
    year = models.IntegerField(blank=True, null=True)

    class Meta:
        db_table = 'covid19paper'


class COVID19Passage(models.Model):
    id = models.IntegerField(primary_key=True)
    paper = models.ForeignKey(COVID19Paper, models.DO_NOTHING, blank=True, null=True)
    tokens = ArrayField(models.TextField())
    text = models.TextField()
    location = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'covid19passage'


class MaterializedPathwayExpressionPlotPptions(models.Model):
    study_id = models.TextField(db_column='study_id')
    tissue_source = models.TextField(db_column='tissue_source')
    time_point = models.PositiveIntegerField(db_column='time_point')
    pathway_set = models.TextField(db_column='pathway_set')

    @staticmethod
    def get_time_point_string(time_point):
        return get_time_point_string(time_point)

    @property
    def time_point_string(self):
        return get_time_point_string(self.time_point)

    class Meta:
        db_table = 'materialized_pathway_expression_plot_options'
        managed = False

# Create your models here.
class TCGAExpression(models.Model):
    id = models.AutoField(primary_key=True)
    gene_name = models.TextField(blank=True, null=True)
    rpkm = customRealField(blank=True, null=True)
    tpm = customRealField(blank=True, null=True)
    sample_type = models.TextField(blank=True, null=True)
    stage = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    project = models.TextField(blank=True, null=True)
    projectID = models.TextField(blank=True, null=True)
    sampleBarcode = models.TextField(blank=True, null=True)
    race = models.TextField(blank=True, null=True)
    sex = models.TextField(blank=True, null=True)
    Code = models.TextField(blank=True, null=True)
    Tissue = models.TextField(blank=True, null=True)
    study_id = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'tcgaExpression'
        indexes = [
            models.Index(fields=['gene_name'])
        ]

# Create your models here.
class GTEXExpression(models.Model):
    id = models.AutoField(primary_key=True)
    gene_name = models.TextField(blank=True, null=True)
    rpkm = customRealField(blank=True, null=True)
    tpm = customRealField(blank=True, null=True)
    sample_type = models.TextField(blank=True, null=True)
    stage = models.TextField(blank=True, null=True)
    type = models.TextField(blank=True, null=True)
    project = models.TextField(blank=True, null=True)
    projectID = models.TextField(blank=True, null=True)
    sampleBarcode = models.TextField(blank=True, null=True)
    race = models.TextField(blank=True, null=True)
    sex = models.TextField(blank=True, null=True)
    Code = models.TextField(blank=True, null=True)
    Tissue = models.TextField(blank=True, null=True)
    study_id = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'gtexExpression'
        indexes = [
            models.Index(fields=['gene_name'])
        ]