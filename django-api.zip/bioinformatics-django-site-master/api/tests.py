from django.test import TestCase
from django.test import Client
from django.urls import reverse
# from rest_framework.reverse import reverse
# from django.http import HttpRequest
# from .api_v1.apiviews import *
from . import models
from tastypie.test import ResourceTestCaseMixin


class JSONResourceTests(ResourceTestCaseMixin, TestCase):
    """
    Test api-v1 and assert that you get back:
    - HTTP of 200
    - The correct content-type(application/json)
    - The correct content is valid JSON
    """
    def test_gene_expression_json(self):
        response = self.api_client.get('/api/v1/gene-expression/', format='json')
        self.assertValidJSONResponse(response)
        self.assertEqual(len(self.deserialize(response)), 0) #TODO why the len and content is empty
        # self.assertKeys(self.deserialize(response), []) #TODO does not return any key

    def test_pathway_expression_json(self):
        response = self.api_client.get('/api/v1/pathway-expression/', format='json')
        self.assertValidJSONResponse(response)

    def test_gene_json(self):
        response = self.api_client.get('/api/v1/gene/', format='json')
        self.assertValidJSONResponse(response)

    def test_possible_gene_name_json(self):
        response = self.api_client.get('/api/v1/plot-options/all-gene-ids/', format='json')
        self.assertValidJSONResponse(response)

    def test_plot_option_gene_expression_json(self):
        response = self.api_client.get('/api/v1/plot-options/gene-expression/', format='json')
        self.assertValidJSONResponse(response)

    def test_pathway_json(self):
        response = self.api_client.get('/api/v1/pathway/', format='json')
        self.assertValidJSONResponse(response)

    def test_differential_gene_expression_json(self):
        response = self.api_client.get('/api/v1/differential-gene-expression/', format='json')
        self.assertValidJSONResponse(response)

class StatusCodeTests(TestCase):
    """
    Tests all the urls and their status code
    """
    def test_gene_expression_status_code(self):
        response = self.client.get('/api/v1/gene-expression/')
        self.assertEquals(response.status_code, 200)

    def test_gene_expression_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:gene_expression'))
        self.assertEquals(response.status_code, 200)

    def test_pathway_expression_status_code(self):
        response = self.client.get('/api/v1/pathway-expression/')
        self.assertEquals(response.status_code, 200)

    def test_pathway_expression_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:pathway_expression'))
        self.assertEquals(response.status_code, 200)

    def test_gene_status_code(self):
        response = self.client.get('/api/v1/gene/')
        self.assertEquals(response.status_code, 200)

    def test_gene_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:gene'))
        self.assertEquals(response.status_code, 200)

    def test_possible_gene_name_status_code(self):
        response = self.client.get('/api/v1/plot-options/all-gene-ids/')
        self.assertEquals(response.status_code, 200)

    def test_possible_gene_names_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:all_gene_ids'))
        self.assertEquals(response.status_code, 200)

    def test_plot_options_gene_expression_status_code(self):
        response = self.client.get('/api/v1/plot-options/gene-expression/')
        self.assertEquals(response.status_code, 200)

    def test_plot_options_gene_expression_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:gene_expression_plot_options'))
        self.assertEquals(response.status_code, 200)

    def test_pathway_status_code(self):
        response = self.client.get('/api/v1/pathway/')
        self.assertEquals(response.status_code, 200)

    def test_pathway_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:pathway'))
        self.assertEquals(response.status_code, 200)

    def test_differential_gene_expression_status_code(self):
        response = self.client.get('/api/v1/differential-gene-expression/')
        self.assertEquals(response.status_code, 200)

    def test_differential_gene_expression_url_by_name(self):
        response = self.client.get(reverse('api:api_v1:differential_gene_expression'))
        self.assertEquals(response.status_code, 200)

class SubjectsModelTests(TestCase):
    """
    Tests two functions for binning age and bmi in Subject model
    """
    def test_age_binned(self):
        subject = models.Subject(age_years=10)
        self.assertEquals(subject.age_binned, '0 - 18 years old')
    def test_bmi_binned(self):
        subject = models.Subject(bmi=28)
        self.assertEquals(subject.bmi_binned, 'overweight')
