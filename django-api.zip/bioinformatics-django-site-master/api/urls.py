from django.urls import path, include

urlpatterns = [
    path('v1/', include(('api.api_v1.urls', 'api_v1'), namespace='api_v1')),
]