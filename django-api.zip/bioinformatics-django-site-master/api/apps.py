from django.apps import AppConfig


class BaseDataAnalysisConfig(AppConfig):
    name = 'api'
